﻿using ImageMagick;
using PdfiumViewer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing.Imaging;
using System.IO;

namespace CFAMatch_OCRImageDistributionProcessor
{
    class Program
    {
        private class ImageMapEntry
        {
            public string OriginalImageName { get; set; }
            public string NewImageName { get; set; }
        }

        private class ProcessStats
        {
            public int FilesScanned;
            public int SupportedFiles;
            public int MatchedFiles;
            public int PdfProcessed;
            public int TifProcessed;
            public int SkippedUnsupported;
            public int SkippedNoMap;
            public int SkippedErrors;
            public int Archived;
        }

        static int Main(string[] args)
        {
            var sw = Stopwatch.StartNew();
            var stats = new ProcessStats();

            try
            {
                string logFolder = GetAppSetting("LogFolder", "Logs");
                Logger.Initialize(logFolder);

                Logger.Info("====================================================");
                Logger.Info("CFAMatch OCR Image Distribution Processor");
                Logger.Info("====================================================");
                Logger.Info("Application Start : " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                Logger.Info("Machine Name      : " + Environment.MachineName);
                Logger.Info("User              : " + Environment.UserName);

                string sourceFolder = GetAppSetting(
                    "SourceFolder",
                    @"\\carefirst.com\corp\share2\blue\Emdeon\Actual EDI Stuff\_CFAMatch\__To_CFAMatch\Processingzone\OCRClaimProcessing");

                string archiveFolder = GetAppSetting(
                    "ArchiveFolder",
                    Path.Combine(sourceFolder, "Archive"));

                string portalImagesFolder = GetAppSetting(
                    "PortalImagesFolder",
                    @"\\carefirst.com\corp\share2\blue\portalimages");

                string blueTmpImgFolder = GetAppSetting(
                    "BlueTmpImgFolder",
                    @"\\carefirst.com\corp\share2\blue\tmp_img");

                string nonBlueTmpImgFolder = GetAppSetting(
                    "NonBlueTmpImgFolder",
                    @"\\carefirst.com\corp\share1\nonblue\tmp_img");

                int pdfRenderDpi = GetIntAppSetting("PdfRenderDpi", 300);

                string connString = GetConnectionString("CFAMatchConnection");

                Logger.Info("Source Folder     : " + sourceFolder);
                Logger.Info("Archive Folder    : " + archiveFolder);
                Logger.Info("Portal Folder     : " + portalImagesFolder);
                Logger.Info("Blue Tmp Folder   : " + blueTmpImgFolder);
                Logger.Info("NonBlue Tmp Folder: " + nonBlueTmpImgFolder);
                Logger.Info("PDF Render DPI    : " + pdfRenderDpi);

                ValidateFolderExists(sourceFolder, "SourceFolder");

                Directory.CreateDirectory(archiveFolder);
                Directory.CreateDirectory(portalImagesFolder);
                Directory.CreateDirectory(blueTmpImgFolder);
                Directory.CreateDirectory(nonBlueTmpImgFolder);

                string workFolder = Path.Combine(sourceFolder, "_Work");
                Directory.CreateDirectory(workFolder);

                Logger.Info("Loading image crosswalk from SQL...");
                var imageMap = LoadImageMap(connString);
                Logger.Info("Crosswalk records loaded: " + imageMap.Count);

                foreach (var filePath in Directory.EnumerateFiles(sourceFolder, "*.*", SearchOption.TopDirectoryOnly))
                {
                    stats.FilesScanned++;

                    string ext = Path.GetExtension(filePath);

                    if (!IsSupportedImageExtension(ext))
                    {
                        stats.SkippedUnsupported++;
                        continue;
                    }

                    stats.SupportedFiles++;

                    string originalFileName = Path.GetFileName(filePath);

                    ImageMapEntry entry;
                    if (!imageMap.TryGetValue(originalFileName, out entry))
                    {
                        stats.SkippedNoMap++;
                        Logger.Warn("No crosswalk mapping found for file. Leaving in source folder: " + originalFileName);
                        continue;
                    }

                    stats.MatchedFiles++;

                    try
                    {
                        Logger.Info("----------------------------------------------------");
                        Logger.Info("Processing File");
                        Logger.Info("----------------------------------------------------");
                        Logger.Info("Original File      : " + originalFileName);
                        Logger.Info("SQL Original Name  : " + entry.OriginalImageName);
                        Logger.Info("SQL New Name       : " + entry.NewImageName);

                        string renamedFilePath = RenameSourceFileUsingOriginalExtension(filePath, entry.NewImageName);

                        Logger.Info("Renamed File       : " + Path.GetFileName(renamedFilePath));

                        if (IsPdfExtension(Path.GetExtension(renamedFilePath)))
                        {
                            ProcessPdfFile(
                                renamedFilePath,
                                portalImagesFolder,
                                blueTmpImgFolder,
                                nonBlueTmpImgFolder,
                                archiveFolder,
                                workFolder,
                                pdfRenderDpi);

                            stats.PdfProcessed++;
                        }
                        else if (IsTiffExtension(Path.GetExtension(renamedFilePath)))
                        {
                            ProcessTifFile(
                                renamedFilePath,
                                portalImagesFolder,
                                blueTmpImgFolder,
                                nonBlueTmpImgFolder,
                                archiveFolder,
                                workFolder);

                            stats.TifProcessed++;
                        }

                        stats.Archived++;
                        Logger.Info("Result             : SUCCESS");
                    }
                    catch (Exception exFile)
                    {
                        stats.SkippedErrors++;
                        Logger.Error("Error processing file: " + originalFileName);
                        Logger.Error(exFile.ToString());
                    }
                }

                TryDeleteEmptyWorkFolder(workFolder);

                sw.Stop();

                Logger.Info("====================================================");
                Logger.Info("PROCESS COMPLETE");
                Logger.Info("====================================================");
                Logger.Info("Files Scanned             : " + stats.FilesScanned);
                Logger.Info("Supported Files           : " + stats.SupportedFiles);
                Logger.Info("Crosswalk Matches         : " + stats.MatchedFiles);
                Logger.Info("PDF Files Processed       : " + stats.PdfProcessed);
                Logger.Info("TIF Files Processed       : " + stats.TifProcessed);
                Logger.Info("Files Archived            : " + stats.Archived);
                Logger.Info("Unsupported Skipped       : " + stats.SkippedUnsupported);
                Logger.Info("Missing Crosswalk Skipped : " + stats.SkippedNoMap);
                Logger.Info("Errors                    : " + stats.SkippedErrors);
                Logger.Info("Duration                  : " + sw.Elapsed);
                Logger.Info("====================================================");

                return stats.SkippedErrors > 0 ? 1 : 0;
            }
            catch (Exception ex)
            {
                Logger.Error("Fatal error.");
                Logger.Error(ex.ToString());
                return 1;
            }
        }

        private static void ProcessPdfFile(
            string pdfSourcePath,
            string portalImagesFolder,
            string blueTmpImgFolder,
            string nonBlueTmpImgFolder,
            string archiveFolder,
            string workFolder,
            int pdfRenderDpi)
        {
            string pdfFileName = Path.GetFileName(pdfSourcePath);
            string baseName = Path.GetFileNameWithoutExtension(pdfSourcePath);

            string portalPdfPath = Path.Combine(portalImagesFolder, pdfFileName);
            string workTifPath = Path.Combine(workFolder, baseName + ".tif");
            string blueTifPath = Path.Combine(blueTmpImgFolder, baseName + ".tif");
            string nonBlueTifPath = Path.Combine(nonBlueTmpImgFolder, baseName + ".tif");

            CopyIfMissingAndVerify(pdfSourcePath, portalPdfPath, "PDF copied to      ");

            if (!IsValidFile(workTifPath) && (!IsValidFile(blueTifPath) || !IsValidFile(nonBlueTifPath)))
            {
                DeleteIfExists(workTifPath);
                ImageConverter.ConvertPdfToTif(pdfSourcePath, workTifPath, pdfRenderDpi);
                VerifyFile(workTifPath, "Created TIF");
                Logger.Info("TIF created        : " + workTifPath);
            }

            if (!IsValidFile(blueTifPath))
                CopyIfMissingAndVerify(workTifPath, blueTifPath, "TIF copied to      ");
            else
                Logger.Info("TIF already exists : " + blueTifPath);

            if (!IsValidFile(nonBlueTifPath))
                CopyIfMissingAndVerify(workTifPath, nonBlueTifPath, "TIF copied to      ");
            else
                Logger.Info("TIF already exists : " + nonBlueTifPath);

            VerifyFile(portalPdfPath, "Portal PDF");
            VerifyFile(blueTifPath, "Blue TIF");
            VerifyFile(nonBlueTifPath, "NonBlue TIF");

            DeleteIfExists(workTifPath);
            ArchiveFile(pdfSourcePath, archiveFolder);
        }

        private static void ProcessTifFile(
            string tifSourcePath,
            string portalImagesFolder,
            string blueTmpImgFolder,
            string nonBlueTmpImgFolder,
            string archiveFolder,
            string workFolder)
        {
            string tifFileName = Path.GetFileName(tifSourcePath);
            string baseName = Path.GetFileNameWithoutExtension(tifSourcePath);

            string blueTifPath = Path.Combine(blueTmpImgFolder, tifFileName);
            string workTifPath = Path.Combine(workFolder, tifFileName);
            string nonBlueTifPath = Path.Combine(nonBlueTmpImgFolder, tifFileName);

            string workPdfPath = Path.Combine(workFolder, baseName + ".pdf");
            string portalPdfPath = Path.Combine(portalImagesFolder, baseName + ".pdf");

            EnsureTargetDoesNotExist(blueTifPath);
            EnsureTargetDoesNotExist(workTifPath);
            EnsureTargetDoesNotExist(nonBlueTifPath);
            EnsureTargetDoesNotExist(workPdfPath);
            EnsureTargetDoesNotExist(portalPdfPath);

            File.Copy(tifSourcePath, blueTifPath);
            Logger.Info("TIF copied to      : " + blueTifPath);

            File.Copy(tifSourcePath, workTifPath);
            File.Move(workTifPath, nonBlueTifPath);
            Logger.Info("TIF moved to       : " + nonBlueTifPath);

            ImageConverter.ConvertTifToPdf(tifSourcePath, workPdfPath);
            Logger.Info("PDF created        : " + workPdfPath);

            File.Move(workPdfPath, portalPdfPath);
            Logger.Info("PDF moved to       : " + portalPdfPath);

            ArchiveFile(tifSourcePath, archiveFolder);
        }

        private static string RenameSourceFileUsingOriginalExtension(string currentFilePath, string sqlNewImageName)
        {
            string currentFolder = Path.GetDirectoryName(currentFilePath);
            string currentExt = Path.GetExtension(currentFilePath);

            string sqlFileNameOnly = Path.GetFileName(sqlNewImageName);
            string newBaseName = Path.GetFileNameWithoutExtension(sqlFileNameOnly);

            if (string.IsNullOrWhiteSpace(newBaseName))
                throw new ApplicationException("NewImageName from SQL is empty or invalid: " + sqlNewImageName);

            string newFileName = newBaseName + currentExt.ToLower();
            string renamedPath = Path.Combine(currentFolder, newFileName);

            if (currentFilePath.Equals(renamedPath, StringComparison.OrdinalIgnoreCase))
                return currentFilePath;

            EnsureTargetDoesNotExist(renamedPath);

            File.Move(currentFilePath, renamedPath);
            return renamedPath;
        }

        private static Dictionary<string, ImageMapEntry> LoadImageMap(string connectionString)
        {
            var map = new Dictionary<string, ImageMapEntry>(StringComparer.OrdinalIgnoreCase);

            using (var conn = new SqlConnection(connectionString))
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
SELECT
    OriginalImageName,
    NewImageName
FROM dbo.tbRefUserCreatedClmImageCrosswalk WITH (NOLOCK)
WHERE OriginalImageName IS NOT NULL
  AND NewImageName IS NOT NULL;";

                conn.Open();

                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        string originalImageName = Convert.ToString(r["OriginalImageName"]).Trim();
                        string newImageName = Convert.ToString(r["NewImageName"]).Trim();

                        if (string.IsNullOrWhiteSpace(originalImageName) || string.IsNullOrWhiteSpace(newImageName))
                            continue;

                        var entry = new ImageMapEntry
                        {
                            OriginalImageName = originalImageName,
                            NewImageName = newImageName
                        };

                        AddMapKey(map, Path.GetFileName(originalImageName), entry);

                        string baseName = Path.GetFileNameWithoutExtension(originalImageName);
                        if (!string.IsNullOrWhiteSpace(baseName))
                        {
                            AddMapKey(map, baseName + ".pdf", entry);
                            AddMapKey(map, baseName + ".tif", entry);
                            AddMapKey(map, baseName + ".tiff", entry);
                        }

                        // Also recognize a source file that was renamed during a prior failed run.
                        string newBaseName = Path.GetFileNameWithoutExtension(newImageName);
                        if (!string.IsNullOrWhiteSpace(newBaseName))
                        {
                            AddMapKey(map, newBaseName + ".pdf", entry);
                            AddMapKey(map, newBaseName + ".tif", entry);
                            AddMapKey(map, newBaseName + ".tiff", entry);
                        }
                    }
                }
            }

            return map;
        }

        private static void AddMapKey(Dictionary<string, ImageMapEntry> map, string key, ImageMapEntry entry)
        {
            if (string.IsNullOrWhiteSpace(key))
                return;

            if (!map.ContainsKey(key))
                map.Add(key, entry);
            else
                Logger.Warn("Duplicate crosswalk key ignored: " + key);
        }

        private static void ArchiveFile(string sourceFilePath, string archiveFolder)
        {
            Directory.CreateDirectory(archiveFolder);

            string archivePath = Path.Combine(archiveFolder, Path.GetFileName(sourceFilePath));

            if (File.Exists(archivePath))
            {
                string baseName = Path.GetFileNameWithoutExtension(sourceFilePath);
                string ext = Path.GetExtension(sourceFilePath);
                string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");

                archivePath = Path.Combine(archiveFolder, baseName + "_" + timestamp + ext);
            }

            File.Move(sourceFilePath, archivePath);
            Logger.Info("Archived to        : " + archivePath);
        }

        private static void CopyIfMissingAndVerify(string sourcePath, string targetPath, string logPrefix)
        {
            VerifyFile(sourcePath, "Source file");

            if (IsValidFile(targetPath))
            {
                Logger.Info("Already exists      : " + targetPath);
                return;
            }

            DeleteIfExists(targetPath);
            File.Copy(sourcePath, targetPath, false);
            VerifyFile(targetPath, "Copied file");
            Logger.Info(logPrefix + ": " + targetPath);
        }

        private static bool IsValidFile(string path)
        {
            if (!File.Exists(path))
                return false;

            return new FileInfo(path).Length > 0;
        }

        private static void VerifyFile(string path, string description)
        {
            if (!File.Exists(path))
                throw new IOException(description + " was not found: " + path);

            if (new FileInfo(path).Length <= 0)
                throw new IOException(description + " exists but is empty: " + path);
        }

        private static void DeleteIfExists(string path)
        {
            if (File.Exists(path))
                File.Delete(path);
        }

        private static void EnsureTargetDoesNotExist(string targetPath)
        {
            if (File.Exists(targetPath))
                throw new IOException("Target file already exists: " + targetPath);
        }

        private static bool IsSupportedImageExtension(string ext)
        {
            return IsPdfExtension(ext) || IsTiffExtension(ext);
        }

        private static bool IsPdfExtension(string ext)
        {
            return ext != null && ext.Equals(".pdf", StringComparison.OrdinalIgnoreCase);
        }

        private static bool IsTiffExtension(string ext)
        {
            return ext != null &&
                   (ext.Equals(".tif", StringComparison.OrdinalIgnoreCase) ||
                    ext.Equals(".tiff", StringComparison.OrdinalIgnoreCase));
        }

        private static void ValidateFolderExists(string path, string settingName)
        {
            if (!Directory.Exists(path))
                throw new DirectoryNotFoundException(settingName + " does not exist: " + path);
        }

        private static string GetAppSetting(string key, string defaultValue)
        {
            string value = ConfigurationManager.AppSettings[key];

            if (string.IsNullOrWhiteSpace(value))
            {
                Logger.Warn("AppSetting '" + key + "' missing. Using default: " + defaultValue);
                return defaultValue;
            }

            return value.Trim();
        }

        private static int GetIntAppSetting(string key, int defaultValue)
        {
            string value = ConfigurationManager.AppSettings[key];

            int result;
            if (!int.TryParse(value, out result))
            {
                Logger.Warn("AppSetting '" + key + "' missing/invalid. Using default: " + defaultValue);
                return defaultValue;
            }

            return result;
        }

        private static string GetConnectionString(string name)
        {
            var cs = ConfigurationManager.ConnectionStrings[name];

            if (cs == null || string.IsNullOrWhiteSpace(cs.ConnectionString))
                throw new ApplicationException("Connection string '" + name + "' is missing or empty.");

            return cs.ConnectionString;
        }

        private static void TryDeleteEmptyWorkFolder(string workFolder)
        {
            try
            {
                if (Directory.Exists(workFolder) && Directory.GetFiles(workFolder).Length == 0)
                    Directory.Delete(workFolder);
            }
            catch
            {
                // Not fatal.
            }
        }
    }

    static class ImageConverter
    {
        public static void ConvertPdfToTif(string pdfPath, string tifPath, int dpi)
        {
            using (var document = PdfDocument.Load(pdfPath))
            using (var images = new MagickImageCollection())
            {
                for (int pageIndex = 0; pageIndex < document.PageCount; pageIndex++)
                {
                    using (var bitmap = document.Render(pageIndex, dpi, dpi, true))
                    using (var ms = new MemoryStream())
                    {
                        bitmap.Save(ms, ImageFormat.Png);
                        ms.Position = 0;

                        var image = new MagickImage(ms);
                        image.Density = new Density(dpi, dpi);
                        image.Format = MagickFormat.Tif;

                        images.Add(image);
                    }
                }

                images.Write(tifPath);
            }
        }

        public static void ConvertTifToPdf(string tifPath, string pdfPath)
        {
            using (var images = new MagickImageCollection())
            {
                images.Read(tifPath);

                foreach (var image in images)
                {
                    image.Format = MagickFormat.Pdf;
                    image.AutoOrient();
                }

                images.Write(pdfPath);
            }
        }
    }

    static class Logger
    {
        private static readonly object _lock = new object();

        public static void Initialize(string logFolder)
        {
            // Console-only logging.
            // The batch script captures console output.
        }

        public static void Info(string message)
        {
            Write("INFO", message);
        }

        public static void Warn(string message)
        {
            Write("WARN", message);
        }

        public static void Error(string message)
        {
            Write("ERROR", message);
        }

        private static void Write(string level, string message)
        {
            lock (_lock)
            {
                Console.WriteLine("[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] [" + level + "] " + message);
            }
        }
    }
}
