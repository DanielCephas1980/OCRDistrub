using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ClaimEntryTool_Corr_DriverFileCreator")]
[assembly: AssemblyDescription("Creates CFA and NCAS correspondence driver files.")]
[assembly: AssemblyCompany("CareFirst")]
[assembly: AssemblyProduct("ClaimEntryTool_Corr_DriverFileCreator")]
[assembly: ComVisible(false)]
[assembly: Guid("26e9d8c1-b958-4c50-a887-77468b9a5e11")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
