ClaimEntryTool_Corr_DriverFileCreator
=========================================

1. Run DatabasePrerequisites.sql against CFAMatch.
2. Update the CFAMatch connection string in App.config.
3. Build the solution as Release.
4. Confirm the execution account can read portalimages and write to both tmp folders and the driver folder.
5. Complete test records using RoutingCode A and B.
6. Run the EXE manually before scheduling it.

Eligibility:
ReviewedBy IS NOT NULL
DateReviewed IS NOT NULL
RoutingCode = A or B
FileExtracted = N

Route A:
Destination image folder = \\carefirst.com\corp\share2\blue\tmp
Driver file = cccYYYYMMDDHH.dat

Route B:
Destination image folder = \\carefirst.com\corp\share1\nonblue\tmp
Driver file = nccYYYYMMDDHH.dat

A record is marked FileExtracted=Y only after the source image is found,
the renamed destination image is verified, and the final driver file exists.

CreateIssueReport defaults to false.
Console logging and database issue tracking always remain enabled.

Exit code 0 = completed.
Exit code 1 = fatal application or route failure.


Driver File Audit
-----------------
Successful rows are updated with ExtractionDriverFileName so the exact
cccYYYYMMDDHH.dat or nccYYYYMMDDHH.dat file can be identified later.
