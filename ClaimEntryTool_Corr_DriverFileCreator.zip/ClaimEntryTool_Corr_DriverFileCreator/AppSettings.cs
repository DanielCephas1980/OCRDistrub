using System;
using System.Configuration;
using System.Text;

namespace ClaimEntryTool_Corr_DriverFileCreator
{
    internal sealed class AppSettings
    {
        public string ConnectionString { get; private set; }
        public string PortalImagesFolder { get; private set; }
        public string PlatformAImageFolder { get; private set; }
        public string PlatformBImageFolder { get; private set; }
        public string DriverFileFolder { get; private set; }
        public bool CreateIssueReport { get; private set; }
        public bool OverwriteExistingDriverFile { get; private set; }
        public bool VerifyCopiedFileLength { get; private set; }
        public int CommandTimeoutSeconds { get; private set; }
        public Encoding DriverFileEncoding { get; private set; }

        public static AppSettings Load()
        {
            var cs = ConfigurationManager.ConnectionStrings["CFAMatch"];

            if (cs == null || string.IsNullOrWhiteSpace(cs.ConnectionString))
                throw new ConfigurationErrorsException(
                    "Connection string 'CFAMatch' is required.");

            return new AppSettings
            {
                ConnectionString = cs.ConnectionString,
                PortalImagesFolder = Require("PortalImagesFolder"),
                PlatformAImageFolder = Require("PlatformAImageFolder"),
                PlatformBImageFolder = Require("PlatformBImageFolder"),
                DriverFileFolder = Require("DriverFileFolder"),
                CreateIssueReport = ReadBool("CreateIssueReport", false),
                OverwriteExistingDriverFile =
                    ReadBool("OverwriteExistingDriverFile", false),
                VerifyCopiedFileLength =
                    ReadBool("VerifyCopiedFileLength", true),
                CommandTimeoutSeconds =
                    ReadInt("CommandTimeoutSeconds", 300),
                DriverFileEncoding =
                    ResolveEncoding(
                        ConfigurationManager.AppSettings["DriverFileEncoding"])
            };
        }

        private static string Require(string key)
        {
            string value = ConfigurationManager.AppSettings[key];

            if (string.IsNullOrWhiteSpace(value))
                throw new ConfigurationErrorsException(
                    "AppSetting '" + key + "' is required.");

            return value.Trim();
        }

        private static bool ReadBool(string key, bool fallback)
        {
            bool parsed;
            return bool.TryParse(
                ConfigurationManager.AppSettings[key],
                out parsed) ? parsed : fallback;
        }

        private static int ReadInt(string key, int fallback)
        {
            int parsed;
            return int.TryParse(
                ConfigurationManager.AppSettings[key],
                out parsed) && parsed > 0
                ? parsed
                : fallback;
        }

        private static Encoding ResolveEncoding(string name)
        {
            return string.Equals(
                name,
                "UTF8",
                StringComparison.OrdinalIgnoreCase)
                ? new UTF8Encoding(false)
                : Encoding.ASCII;
        }
    }
}
