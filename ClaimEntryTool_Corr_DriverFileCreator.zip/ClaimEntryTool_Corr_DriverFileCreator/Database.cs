using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace ClaimEntryTool_Corr_DriverFileCreator
{
    internal sealed class Database
    {
        private readonly AppSettings _settings;

        public Database(AppSettings settings)
        {
            _settings = settings;
        }

        public void TestConnection()
        {
            Console.WriteLine("DATABASE CONNECTION");
            Console.WriteLine("------------------------------------------------------------");

            using (var connection =
                   new SqlConnection(_settings.ConnectionString))
            {
                connection.Open();
                Console.WriteLine("[OK] Server: " + connection.DataSource);
                Console.WriteLine("[OK] Database: " + connection.Database);
            }

            Console.WriteLine();
        }

        public List<CorrespondenceRecord> GetPendingRecords(
            string routingCode)
        {
            const string sql = @"
SELECT
    c.ClearinghouseID,
    c.RoutingCode,
    c.ReviewedBy,
    c.DateReviewed,
    x.id AS CrosswalkID,
    x.NewImageName,
    x.CorrespondenceImageName
FROM dbo.stage_Correspondence AS c
OUTER APPLY
(
    SELECT TOP (1)
        cw.id,
        cw.NewImageName,
        cw.CorrespondenceImageName
    FROM dbo.tbRefUserCreatedClmImageCrosswalk AS cw
    WHERE LTRIM(RTRIM(cw.OriginalClearinghouseID)) =
          LTRIM(RTRIM(c.ClearinghouseID))
    ORDER BY cw.id DESC
) AS x
WHERE c.ReviewedBy IS NOT NULL
  AND c.DateReviewed IS NOT NULL
  AND c.RoutingCode = @RoutingCode
  AND ISNULL(c.FileExtracted, 'N') = 'N'
ORDER BY c.DateReviewed, c.ClearinghouseID;";

            var results = new List<CorrespondenceRecord>();

            using (var connection =
                   new SqlConnection(_settings.ConnectionString))
            using (var command =
                   new SqlCommand(sql, connection))
            {
                command.CommandTimeout = _settings.CommandTimeoutSeconds;
                command.Parameters.Add(
                    "@RoutingCode",
                    SqlDbType.VarChar,
                    10).Value = routingCode;

                connection.Open();

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        results.Add(new CorrespondenceRecord
                        {
                            ClearinghouseID = GetString(reader, "ClearinghouseID"),
                            RoutingCode = GetString(reader, "RoutingCode"),
                            ReviewedBy = GetString(reader, "ReviewedBy"),
                            DateReviewed = GetDate(reader, "DateReviewed"),
                            CrosswalkID = GetInt(reader, "CrosswalkID"),
                            NewImageName = GetString(reader, "NewImageName"),
                            CorrespondenceImageName =
                                GetString(reader, "CorrespondenceImageName")
                        });
                    }
                }
            }

            return results;
        }

        public void UpdateIssue(
            string clearinghouseId,
            string status,
            string message)
        {
            const string sql = @"
UPDATE dbo.stage_Correspondence
SET ExtractionStatus = @Status,
    ExtractionMessage = @Message,
    LastExtractionAttemptDate = GETDATE()
WHERE ClearinghouseID = @ClearinghouseID
  AND ISNULL(FileExtracted, 'N') = 'N';";

            using (var connection =
                   new SqlConnection(_settings.ConnectionString))
            using (var command =
                   new SqlCommand(sql, connection))
            {
                command.CommandTimeout = _settings.CommandTimeoutSeconds;
                command.Parameters.Add("@Status", SqlDbType.VarChar, 30)
                    .Value = Limit(status, 30);
                command.Parameters.Add("@Message", SqlDbType.VarChar, 1000)
                    .Value = (object)Limit(message, 1000) ?? DBNull.Value;
                command.Parameters.Add("@ClearinghouseID", SqlDbType.VarChar, 100)
                    .Value = clearinghouseId;

                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public int MarkSuccessfullyExtracted(
            IList<PreparedRecord> records,
            string driverFileName)
        {
            if (records == null || records.Count == 0)
                return 0;

            const string sql = @"
UPDATE dbo.stage_Correspondence
SET FileExtracted = 'Y',
    ExtractionDate = GETDATE(),
    ExtractionStatus = 'Success',
    ExtractionMessage = NULL,
    LastExtractionAttemptDate = GETDATE(),
    ExtractionDriverFileName = @DriverFileName
WHERE ClearinghouseID = @ClearinghouseID
  AND ISNULL(FileExtracted, 'N') = 'N';";

            using (var connection =
                   new SqlConnection(_settings.ConnectionString))
            {
                connection.Open();

                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        int updated = 0;

                        foreach (PreparedRecord record in records)
                        {
                            using (var command =
                                   new SqlCommand(sql, connection, transaction))
                            {
                                command.CommandTimeout =
                                    _settings.CommandTimeoutSeconds;
                                command.Parameters.Add(
                                    "@ClearinghouseID",
                                    SqlDbType.VarChar,
                                    100).Value =
                                        record.Record.ClearinghouseID;

                                command.Parameters.Add(
                                    "@DriverFileName",
                                    SqlDbType.VarChar,
                                    100).Value =
                                        driverFileName;

                                updated += command.ExecuteNonQuery();
                            }
                        }

                        transaction.Commit();
                        return updated;
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }

        private static string GetString(IDataRecord row, string name)
        {
            int ordinal = row.GetOrdinal(name);
            return row.IsDBNull(ordinal)
                ? null
                : Convert.ToString(row.GetValue(ordinal)).Trim();
        }

        private static DateTime? GetDate(IDataRecord row, string name)
        {
            int ordinal = row.GetOrdinal(name);
            return row.IsDBNull(ordinal)
                ? (DateTime?)null
                : Convert.ToDateTime(row.GetValue(ordinal));
        }

        private static int? GetInt(IDataRecord row, string name)
        {
            int ordinal = row.GetOrdinal(name);
            return row.IsDBNull(ordinal)
                ? (int?)null
                : Convert.ToInt32(row.GetValue(ordinal));
        }

        private static string Limit(string value, int max)
        {
            if (string.IsNullOrWhiteSpace(value)) return null;
            value = value.Trim();
            return value.Length <= max ? value : value.Substring(0, max);
        }
    }
}
