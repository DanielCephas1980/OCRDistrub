using System;

namespace ClaimEntryTool_Corr_DriverFileCreator
{
    internal sealed class RouteDefinition
    {
        public string RoutingCode { get; private set; }
        public string DisplayName { get; private set; }
        public string DriverFilePrefix { get; private set; }
        public string DestinationFolder { get; private set; }

        public static RouteDefinition PlatformA(AppSettings settings)
        {
            return new RouteDefinition
            {
                RoutingCode = "A",
                DisplayName = "Platform A / CFA (RoutingCode = A)",
                DriverFilePrefix = "ccc",
                DestinationFolder = settings.PlatformAImageFolder
            };
        }

        public static RouteDefinition PlatformB(AppSettings settings)
        {
            return new RouteDefinition
            {
                RoutingCode = "B",
                DisplayName = "Platform B / NCAS (RoutingCode = B)",
                DriverFilePrefix = "ncc",
                DestinationFolder = settings.PlatformBImageFolder
            };
        }
    }

    internal sealed class RouteRunSummary
    {
        public RouteDefinition Route { get; set; }
        public int RecordsFound { get; set; }
        public int SuccessfullyCopied { get; set; }
        public int DriverEntries { get; set; }
        public int MarkedExtracted { get; set; }
        public int MissingCrosswalk { get; set; }
        public int MissingNewImageName { get; set; }
        public int MissingCorrespondenceImageName { get; set; }
        public int MissingSourceImage { get; set; }
        public int CopyErrors { get; set; }
        public int OtherIssues { get; set; }
        public bool DriverFileCreated { get; set; }
        public string DriverFilePath { get; set; }
        public bool HasFatalError { get; set; }
        public string FatalErrorMessage { get; set; }

        public static RouteRunSummary Fatal(
            RouteDefinition route,
            Exception ex)
        {
            return new RouteRunSummary
            {
                Route = route,
                HasFatalError = true,
                FatalErrorMessage = ex.ToString()
            };
        }
    }
}
