using System;
using System.Diagnostics;

namespace ClaimEntryTool_Corr_DriverFileCreator
{
    internal static class Program
    {
        private static int Main()
        {
            var timer = Stopwatch.StartNew();
            RouteRunSummary a = null;
            RouteRunSummary b = null;
            int exitCode = 0;

            try
            {
                AppSettings settings = AppSettings.Load();
                ConsoleLog.WriteStartup(settings);
                StartupValidator.Validate(settings);

                var database = new Database(settings);
                database.TestConnection();

                var processor = new DriverFileProcessor(settings, database);

                a = RunRoute(processor, RouteDefinition.PlatformA(settings));
                b = RunRoute(processor, RouteDefinition.PlatformB(settings));

                if ((a != null && a.HasFatalError) ||
                    (b != null && b.HasFatalError))
                {
                    exitCode = 1;
                }
            }
            catch (Exception ex)
            {
                exitCode = 1;
                Console.Error.WriteLine();
                Console.Error.WriteLine("============================================================");
                Console.Error.WriteLine("FATAL APPLICATION ERROR");
                Console.Error.WriteLine("============================================================");
                Console.Error.WriteLine(ex);
            }
            finally
            {
                timer.Stop();
                ConsoleLog.WriteFinalSummary(a, b, timer.Elapsed, exitCode);
            }

            return exitCode;
        }

        private static RouteRunSummary RunRoute(
            DriverFileProcessor processor,
            RouteDefinition route)
        {
            try
            {
                return processor.Process(route);
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine();
                Console.Error.WriteLine("============================================================");
                Console.Error.WriteLine("FATAL ROUTE ERROR - " + route.DisplayName);
                Console.Error.WriteLine("============================================================");
                Console.Error.WriteLine(ex);

                return RouteRunSummary.Fatal(route, ex);
            }
        }
    }
}
