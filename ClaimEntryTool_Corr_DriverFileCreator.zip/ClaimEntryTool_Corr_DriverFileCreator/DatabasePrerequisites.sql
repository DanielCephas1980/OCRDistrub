USE [CFAMatch];
GO

IF COL_LENGTH('dbo.stage_Correspondence', 'FileExtracted') IS NULL
BEGIN
    ALTER TABLE dbo.stage_Correspondence
    ADD FileExtracted VARCHAR(1) NOT NULL
        CONSTRAINT DF_stage_Correspondence_FileExtracted DEFAULT ('N');
END
GO

IF COL_LENGTH('dbo.stage_Correspondence', 'ExtractionDate') IS NULL
    ALTER TABLE dbo.stage_Correspondence ADD ExtractionDate DATETIME NULL;
GO

IF COL_LENGTH('dbo.stage_Correspondence', 'ExtractionStatus') IS NULL
    ALTER TABLE dbo.stage_Correspondence ADD ExtractionStatus VARCHAR(30) NULL;
GO

IF COL_LENGTH('dbo.stage_Correspondence', 'ExtractionMessage') IS NULL
    ALTER TABLE dbo.stage_Correspondence ADD ExtractionMessage VARCHAR(1000) NULL;
GO

IF COL_LENGTH('dbo.stage_Correspondence', 'LastExtractionAttemptDate') IS NULL
    ALTER TABLE dbo.stage_Correspondence ADD LastExtractionAttemptDate DATETIME NULL;
GO

IF COL_LENGTH('dbo.stage_Correspondence', 'ExtractionDriverFileName') IS NULL
    ALTER TABLE dbo.stage_Correspondence ADD ExtractionDriverFileName VARCHAR(100) NULL;
GO

IF COL_LENGTH(
    'dbo.tbRefUserCreatedClmImageCrosswalk',
    'CorrespondenceImageName') IS NULL
BEGIN
    ALTER TABLE dbo.tbRefUserCreatedClmImageCrosswalk
    ADD CorrespondenceImageName AS
    (
        CONVERT(VARCHAR(50),
            CASE
                WHEN NewImageName IS NULL THEN NULL
                WHEN CHARINDEX('.', REVERSE(NewImageName)) > 0
                    THEN LEFT(
                        NewImageName,
                        LEN(NewImageName) -
                        CHARINDEX('.', REVERSE(NewImageName))
                    ) + '.001'
                ELSE NewImageName + '.001'
            END)
    ) PERSISTED;
END
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.check_constraints
    WHERE name = 'CK_stage_Correspondence_FileExtracted'
)
BEGIN
    ALTER TABLE dbo.stage_Correspondence
    ADD CONSTRAINT CK_stage_Correspondence_FileExtracted
        CHECK (FileExtracted IN ('Y', 'N'));
END
GO
