using System;
using System.IO;

namespace ClaimEntryTool_Corr_DriverFileCreator
{
    internal static class StartupValidator
    {
        public static void Validate(AppSettings settings)
        {
            Console.WriteLine("VALIDATING CONFIGURATION");
            Console.WriteLine("------------------------------------------------------------");

            Readable("Portal Images", settings.PortalImagesFolder);
            Writable("Platform A Destination", settings.PlatformAImageFolder);
            Writable("Platform B Destination", settings.PlatformBImageFolder);
            Writable("Driver File Folder", settings.DriverFileFolder);

            Console.WriteLine("Configuration validation completed successfully.");
            Console.WriteLine();
        }

        private static void Readable(string label, string path)
        {
            if (!Directory.Exists(path))
                throw new DirectoryNotFoundException(
                    label + " folder was not found: " + path);

            Console.WriteLine("[OK] " + label);
            Console.WriteLine("     " + path);
        }

        private static void Writable(string label, string path)
        {
            Directory.CreateDirectory(path);

            string testFile = Path.Combine(
                path,
                ".write_test_" + Guid.NewGuid().ToString("N") + ".tmp");

            try
            {
                File.WriteAllText(testFile, "test");
                File.Delete(testFile);
            }
            catch (Exception ex)
            {
                throw new IOException(
                    label + " folder is not writable: " + path,
                    ex);
            }

            Console.WriteLine("[OK] " + label);
            Console.WriteLine("     " + path);
        }
    }
}
