using System;

namespace ClaimEntryTool_Corr_DriverFileCreator
{
    internal sealed class CorrespondenceRecord
    {
        public string ClearinghouseID { get; set; }
        public string RoutingCode { get; set; }
        public string ReviewedBy { get; set; }
        public DateTime? DateReviewed { get; set; }
        public int? CrosswalkID { get; set; }
        public string NewImageName { get; set; }
        public string CorrespondenceImageName { get; set; }
        public string SourcePath { get; set; }
        public string DestinationPath { get; set; }
    }

    internal sealed class PreparedRecord
    {
        public CorrespondenceRecord Record { get; set; }
        public string DestinationPath { get; set; }
        public bool DestinationCreatedThisRun { get; set; }
    }

    internal sealed class ProcessingIssue
    {
        public string ClearinghouseID { get; set; }
        public string RoutingCode { get; set; }
        public string NewImageName { get; set; }
        public string CorrespondenceImageName { get; set; }
        public string SourcePath { get; set; }
        public string DestinationPath { get; set; }
        public string Status { get; set; }
        public string Message { get; set; }
        public DateTime AttemptDate { get; set; }
    }
}
