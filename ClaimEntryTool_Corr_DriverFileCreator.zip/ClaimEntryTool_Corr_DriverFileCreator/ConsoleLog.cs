using System;
using System.Reflection;

namespace ClaimEntryTool_Corr_DriverFileCreator
{
    internal static class ConsoleLog
    {
        public static void WriteStartup(AppSettings settings)
        {
            Assembly assembly = Assembly.GetExecutingAssembly();

            Console.WriteLine("============================================================");
            Console.WriteLine("ClaimEntryTool_Corr_DriverFileCreator");
            Console.WriteLine("Version: " + assembly.GetName().Version);
            Console.WriteLine("Machine: " + Environment.MachineName);
            Console.WriteLine("User: " + Environment.UserDomainName + "\\" + Environment.UserName);
            Console.WriteLine("Started: " + DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss tt"));
            Console.WriteLine("Executable: " + assembly.Location);
            Console.WriteLine("Config: " + AppDomain.CurrentDomain.SetupInformation.ConfigurationFile);
            Console.WriteLine("============================================================");
            Console.WriteLine();
            Console.WriteLine("CONFIGURATION");
            Console.WriteLine("------------------------------------------------------------");
            Value("Portal Images", settings.PortalImagesFolder);
            Value("Platform A Destination", settings.PlatformAImageFolder);
            Value("Platform B Destination", settings.PlatformBImageFolder);
            Value("Driver File Folder", settings.DriverFileFolder);
            Value("Issue Reports", settings.CreateIssueReport ? "Enabled" : "Disabled");
            Value("Overwrite Driver File",
                settings.OverwriteExistingDriverFile ? "Enabled" : "Disabled");
            Value("Verify File Length",
                settings.VerifyCopiedFileLength ? "Enabled" : "Disabled");
            Value("Command Timeout",
                settings.CommandTimeoutSeconds + " seconds");
            Console.WriteLine();
        }

        public static void WriteFinalSummary(
            RouteRunSummary a,
            RouteRunSummary b,
            TimeSpan elapsed,
            int exitCode)
        {
            Console.WriteLine();
            Console.WriteLine("============================================================");
            Console.WriteLine("RUN SUMMARY");
            Console.WriteLine("============================================================");

            RouteSummary(a);
            RouteSummary(b);

            Value("Elapsed Time", elapsed.ToString());
            Value("Exit Code", exitCode.ToString());
            Value("Finished", DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss tt"));
            Console.WriteLine("============================================================");
        }

        public static void Value(string label, string value)
        {
            Console.WriteLine(label.PadRight(32, '.') + (value ?? "(null)"));
        }

        private static void RouteSummary(RouteRunSummary summary)
        {
            if (summary == null) return;

            Console.WriteLine();
            Console.WriteLine(summary.Route.DisplayName);
            Console.WriteLine(new string('-', summary.Route.DisplayName.Length));
            Value("Records Found", summary.RecordsFound.ToString("N0"));
            Value("Successfully Copied", summary.SuccessfullyCopied.ToString("N0"));
            Value("Driver File Entries", summary.DriverEntries.ToString("N0"));
            Value("Marked Extracted", summary.MarkedExtracted.ToString("N0"));
            Value("Missing Crosswalk", summary.MissingCrosswalk.ToString("N0"));
            Value("Missing NewImageName", summary.MissingNewImageName.ToString("N0"));
            Value("Missing Corr Image Name",
                summary.MissingCorrespondenceImageName.ToString("N0"));
            Value("Missing Source Image", summary.MissingSourceImage.ToString("N0"));
            Value("Copy Errors", summary.CopyErrors.ToString("N0"));
            Value("Other Issues", summary.OtherIssues.ToString("N0"));
            Value("Driver File Created", summary.DriverFileCreated ? "YES" : "NO");
            Value("Driver File", summary.DriverFilePath ?? "(none)");
            Value("Fatal Error", summary.HasFatalError ? "YES" : "NO");
        }
    }
}
