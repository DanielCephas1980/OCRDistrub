using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace ClaimEntryTool_Corr_DriverFileCreator
{
    internal sealed class DriverFileProcessor
    {
        private readonly AppSettings _settings;
        private readonly Database _database;

        public DriverFileProcessor(
            AppSettings settings,
            Database database)
        {
            _settings = settings;
            _database = database;
        }

        public RouteRunSummary Process(RouteDefinition route)
        {
            var summary = new RouteRunSummary { Route = route };
            var issues = new List<ProcessingIssue>();
            var prepared = new List<PreparedRecord>();

            Header(route);

            Console.WriteLine("Loading eligible records...");
            List<CorrespondenceRecord> records =
                _database.GetPendingRecords(route.RoutingCode);

            summary.RecordsFound = records.Count;
            Console.WriteLine("Records found: " + records.Count.ToString("N0"));
            Console.WriteLine();

            if (records.Count == 0)
            {
                Console.WriteLine(
                    "No eligible records were found. No driver file will be created.");
                return summary;
            }

            for (int i = 0; i < records.Count; i++)
            {
                ProcessRecord(
                    records[i],
                    route,
                    i + 1,
                    records.Count,
                    prepared,
                    issues,
                    summary);
            }

            if (prepared.Count == 0)
            {
                Console.WriteLine();
                Console.WriteLine(
                    "No records passed all validations. No driver file will be created.");
                WriteIssueReport(route, issues);
                return summary;
            }

            try
            {
                string driverPath = CreateDriverFile(route, prepared);

                summary.DriverFileCreated = true;
                summary.DriverFilePath = driverPath;
                summary.DriverEntries = prepared.Count;
                summary.MarkedExtracted =
                    _database.MarkSuccessfullyExtracted(
                        prepared,
                        Path.GetFileName(driverPath));

                Console.WriteLine();
                Console.WriteLine(
                    "Database success updates completed: " +
                    summary.MarkedExtracted.ToString("N0"));
            }
            catch
            {
                CleanupCreatedFiles(prepared);
                throw;
            }
            finally
            {
                WriteIssueReport(route, issues);
            }

            return summary;
        }

        private void ProcessRecord(
            CorrespondenceRecord record,
            RouteDefinition route,
            int number,
            int total,
            IList<PreparedRecord> prepared,
            IList<ProcessingIssue> issues,
            RouteRunSummary summary)
        {
            Console.WriteLine("------------------------------------------------------------");
            Console.WriteLine("Record " + number + " of " + total);
            Console.WriteLine("------------------------------------------------------------");
            ConsoleLog.Value("ClearinghouseID", record.ClearinghouseID);
            ConsoleLog.Value("Routing Code", record.RoutingCode);
            ConsoleLog.Value("Reviewed By", record.ReviewedBy);
            ConsoleLog.Value("Date Reviewed",
                record.DateReviewed.HasValue
                    ? record.DateReviewed.Value.ToString("MM/dd/yyyy hh:mm:ss tt")
                    : "(null)");

            if (!record.CrosswalkID.HasValue)
            {
                summary.MissingCrosswalk++;
                Issue(record, route, issues, summary,
                    "MissingCrosswalk",
                    "No crosswalk row was found using ClearinghouseID = OriginalClearinghouseID.");
                return;
            }

            ConsoleLog.Value(
                "Crosswalk",
                "FOUND (ID " + record.CrosswalkID.Value + ")");

            if (string.IsNullOrWhiteSpace(record.NewImageName))
            {
                summary.MissingNewImageName++;
                Issue(record, route, issues, summary,
                    "MissingNewImageName",
                    "The crosswalk row does not contain NewImageName.");
                return;
            }

            if (string.IsNullOrWhiteSpace(record.CorrespondenceImageName))
            {
                summary.MissingCorrespondenceImageName++;
                Issue(record, route, issues, summary,
                    "MissingCorrespondenceImageName",
                    "The crosswalk row does not contain CorrespondenceImageName.");
                return;
            }

            record.SourcePath = Path.Combine(
                _settings.PortalImagesFolder,
                record.NewImageName);

            record.DestinationPath = Path.Combine(
                route.DestinationFolder,
                record.CorrespondenceImageName);

            ConsoleLog.Value("NewImageName", record.NewImageName);
            ConsoleLog.Value(
                "Correspondence Image",
                record.CorrespondenceImageName);
            ConsoleLog.Value("Source Path", record.SourcePath);
            ConsoleLog.Value("Destination Path", record.DestinationPath);

            Console.Write("Checking source image... ");

            if (!File.Exists(record.SourcePath))
            {
                Console.WriteLine("FAILED");
                summary.MissingSourceImage++;
                Issue(record, route, issues, summary,
                    "MissingSourceImage",
                    "Source image was not found: " + record.SourcePath);
                return;
            }

            Console.WriteLine("SUCCESS");

            try
            {
                bool created = CopyAndVerify(
                    record.SourcePath,
                    record.DestinationPath);

                summary.SuccessfullyCopied++;

                prepared.Add(new PreparedRecord
                {
                    Record = record,
                    DestinationPath = record.DestinationPath,
                    DestinationCreatedThisRun = created
                });

                Console.WriteLine("Queued for driver file... SUCCESS");
                Console.WriteLine("Record result... SUCCESS");
            }
            catch (Exception ex)
            {
                summary.CopyErrors++;
                Issue(record, route, issues, summary,
                    "CopyFailed",
                    ex.Message);
            }
        }

        private bool CopyAndVerify(
            string sourcePath,
            string destinationPath)
        {
            Console.Write("Copying image... ");

            Directory.CreateDirectory(
                Path.GetDirectoryName(destinationPath));

            if (File.Exists(destinationPath))
            {
                FileInfo existing = new FileInfo(destinationPath);
                FileInfo source = new FileInfo(sourcePath);

                if (existing.Length == source.Length &&
                    existing.Length > 0)
                {
                    Console.WriteLine(
                        "DESTINATION ALREADY EXISTS AND MATCHES");
                    return false;
                }

                throw new IOException(
                    "Destination image already exists and does not match source: " +
                    destinationPath);
            }

            File.Copy(sourcePath, destinationPath, false);
            Console.WriteLine("SUCCESS");
            Console.Write("Verifying copied image... ");

            if (!File.Exists(destinationPath))
                throw new IOException(
                    "Copied image was not found at destination.");

            FileInfo copied = new FileInfo(destinationPath);

            if (copied.Length <= 0)
                throw new IOException("Copied image is empty.");

            if (_settings.VerifyCopiedFileLength)
            {
                FileInfo source = new FileInfo(sourcePath);

                if (source.Length != copied.Length)
                    throw new IOException(
                        "Copied image length does not match source.");
            }

            Console.WriteLine("SUCCESS");
            return true;
        }

        private string CreateDriverFile(
            RouteDefinition route,
            IList<PreparedRecord> prepared)
        {
            string name =
                route.DriverFilePrefix +
                DateTime.Now.ToString("yyyyMMddHH") +
                ".dat";

            string finalPath = Path.Combine(
                _settings.DriverFileFolder,
                name);

            string tempPath = finalPath + ".tmp";

            Console.WriteLine();
            Console.WriteLine("CREATING DRIVER FILE");
            Console.WriteLine("------------------------------------------------------------");
            ConsoleLog.Value("Temporary File", tempPath);
            ConsoleLog.Value("Final File", finalPath);
            ConsoleLog.Value("Entries", prepared.Count.ToString("N0"));

            if (File.Exists(finalPath) &&
                !_settings.OverwriteExistingDriverFile)
            {
                throw new IOException(
                    "Driver file already exists and overwrite is disabled: " +
                    finalPath);
            }

            if (File.Exists(tempPath))
                File.Delete(tempPath);

            Console.Write("Writing temporary file... ");

            using (var stream = new FileStream(
                tempPath,
                FileMode.CreateNew,
                FileAccess.Write,
                FileShare.None,
                65536,
                FileOptions.WriteThrough))
            using (var writer = new StreamWriter(
                stream,
                _settings.DriverFileEncoding,
                65536))
            {
                foreach (PreparedRecord item in prepared)
                    writer.WriteLine(
                        item.Record.CorrespondenceImageName);

                writer.Flush();
                stream.Flush(true);
            }

            Console.WriteLine("SUCCESS");
            Console.Write("Verifying temporary file... ");

            string[] actual = File.ReadAllLines(
                tempPath,
                _settings.DriverFileEncoding);

            string[] expected = prepared
                .Select(x => x.Record.CorrespondenceImageName)
                .ToArray();

            if (actual.Length != expected.Length)
                throw new IOException(
                    "Driver file line count verification failed.");

            for (int i = 0; i < expected.Length; i++)
            {
                if (!string.Equals(
                    actual[i].Trim(),
                    expected[i],
                    StringComparison.OrdinalIgnoreCase))
                {
                    throw new IOException(
                        "Driver file verification failed at line " +
                        (i + 1) + ".");
                }
            }

            Console.WriteLine("SUCCESS");
            Console.Write("Finalizing driver file... ");

            if (File.Exists(finalPath))
                File.Delete(finalPath);

            File.Move(tempPath, finalPath);

            if (!File.Exists(finalPath))
                throw new IOException(
                    "Final driver file was not created.");

            Console.WriteLine("SUCCESS");
            Console.WriteLine("Driver file complete: " + finalPath);

            return finalPath;
        }

        private void Issue(
            CorrespondenceRecord record,
            RouteDefinition route,
            IList<ProcessingIssue> issues,
            RouteRunSummary summary,
            string status,
            string message)
        {
            Console.WriteLine("Record result... FAILED");
            ConsoleLog.Value("Status", status);
            ConsoleLog.Value("Message", message);

            try
            {
                _database.UpdateIssue(
                    record.ClearinghouseID,
                    status,
                    message);

                Console.WriteLine("Database issue status... UPDATED");
            }
            catch (Exception ex)
            {
                summary.OtherIssues++;
                Console.WriteLine("Database issue status... FAILED");
                Console.WriteLine(ex.Message);
            }

            issues.Add(new ProcessingIssue
            {
                ClearinghouseID = record.ClearinghouseID,
                RoutingCode = route.RoutingCode,
                NewImageName = record.NewImageName,
                CorrespondenceImageName = record.CorrespondenceImageName,
                SourcePath = record.SourcePath,
                DestinationPath = record.DestinationPath,
                Status = status,
                Message = message,
                AttemptDate = DateTime.Now
            });
        }

        private void WriteIssueReport(
            RouteDefinition route,
            IList<ProcessingIssue> issues)
        {
            if (!_settings.CreateIssueReport ||
                issues == null ||
                issues.Count == 0)
                return;

            string path = Path.Combine(
                _settings.DriverFileFolder,
                "CorrespondenceIssues_" +
                route.RoutingCode + "_" +
                DateTime.Now.ToString("yyyyMMddHHmmss") +
                ".csv");

            using (var writer = new StreamWriter(
                path,
                false,
                new UTF8Encoding(false)))
            {
                writer.WriteLine(
                    "ClearinghouseID,RoutingCode,NewImageName,CorrespondenceImageName,SourcePath,DestinationPath,Status,Message,AttemptDate");

                foreach (ProcessingIssue issue in issues)
                {
                    writer.WriteLine(string.Join(",",
                        Csv(issue.ClearinghouseID),
                        Csv(issue.RoutingCode),
                        Csv(issue.NewImageName),
                        Csv(issue.CorrespondenceImageName),
                        Csv(issue.SourcePath),
                        Csv(issue.DestinationPath),
                        Csv(issue.Status),
                        Csv(issue.Message),
                        Csv(issue.AttemptDate.ToString(
                            "yyyy-MM-dd HH:mm:ss"))));
                }
            }

            Console.WriteLine("Issue report created: " + path);
        }

        private static void CleanupCreatedFiles(
            IEnumerable<PreparedRecord> records)
        {
            Console.WriteLine();
            Console.WriteLine(
                "Route finalization failed. Cleaning up destination images created by this run...");

            foreach (PreparedRecord record in records)
            {
                if (!record.DestinationCreatedThisRun)
                    continue;

                try
                {
                    if (File.Exists(record.DestinationPath))
                    {
                        File.Delete(record.DestinationPath);
                        Console.WriteLine("Deleted: " + record.DestinationPath);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(
                        "Unable to delete: " +
                        record.DestinationPath +
                        " | " + ex.Message);
                }
            }
        }

        private static string Csv(string value)
        {
            return "\"" +
                   (value ?? string.Empty).Replace("\"", "\"\"") +
                   "\"";
        }

        private static void Header(RouteDefinition route)
        {
            Console.WriteLine();
            Console.WriteLine("============================================================");
            Console.WriteLine("PROCESSING " + route.DisplayName.ToUpperInvariant());
            Console.WriteLine("============================================================");
            ConsoleLog.Value(
                "Destination Folder",
                route.DestinationFolder);
            ConsoleLog.Value(
                "Driver Prefix",
                route.DriverFilePrefix);
            Console.WriteLine();
        }
    }
}
