using System;
using System.Collections.Generic;
using System.Configuration;

namespace CFAMatch_ImageReconciliation
{
    public sealed class AppSettings
    {
        public string ApplicationName { get; private set; }
        public string ApplicationVersion { get; private set; }
        public string ConnectionString { get; private set; }
        public int CopyRetryCount { get; private set; }
        public int CopyRetryDelayMilliseconds { get; private set; }
        public int PdfRenderDpi { get; private set; }
        public bool ValidateAllFoldersAtStartup { get; private set; }
        public bool DryRun { get; private set; }
        public IList<NamedFolder> RequiredFolders { get; private set; }
        public IList<NamedFolder> RecoveryFolders { get; private set; }

        public static AppSettings Load()
        {
            ConnectionStringSettings connection = ConfigurationManager.ConnectionStrings["CFAMatch"];
            if (connection == null || string.IsNullOrWhiteSpace(connection.ConnectionString))
            {
                throw new ConfigurationErrorsException("The CFAMatch connection string is missing from App.config.");
            }

            return new AppSettings
            {
                ApplicationName = GetString("ApplicationName", "CFAMatch Image Reconciliation"),
                ApplicationVersion = GetString("ApplicationVersion", "1.0.0"),
                ConnectionString = connection.ConnectionString,
                CopyRetryCount = GetInt("CopyRetryCount", 3, 1, 10),
                CopyRetryDelayMilliseconds = GetInt("CopyRetryDelayMilliseconds", 2000, 0, 60000),
                PdfRenderDpi = GetInt("PdfRenderDpi", 300, 100, 600),
                ValidateAllFoldersAtStartup = GetBool("ValidateAllFoldersAtStartup", true),
                DryRun = GetBool("DryRun", false),
                RequiredFolders = new List<NamedFolder>
                {
                    new NamedFolder("Portal Images", GetRequiredString("PortalImagesPath")),
                    new NamedFolder("Blue Tmp Image", GetRequiredString("BlueTmpImagePath")),
                    new NamedFolder("NonBlue Tmp Image", GetRequiredString("NonBlueTmpImagePath"))
                },
                RecoveryFolders = new List<NamedFolder>
                {
                    new NamedFolder("OCR Claim Processing", GetRequiredString("OCRClaimProcessingPath")),
                    new NamedFolder("OCR Claim Processing Archive", GetRequiredString("OCRClaimProcessingArchivePath")),
                    new NamedFolder("Data Redaction Processing", GetRequiredString("DataRedactionProcessingPath"))
                }
            };
        }

        private static string GetRequiredString(string key)
        {
            string value = ConfigurationManager.AppSettings[key];
            if (string.IsNullOrWhiteSpace(value))
            {
                throw new ConfigurationErrorsException("Required App.config setting is missing: " + key);
            }
            return value.Trim();
        }

        private static string GetString(string key, string defaultValue)
        {
            string value = ConfigurationManager.AppSettings[key];
            return string.IsNullOrWhiteSpace(value) ? defaultValue : value.Trim();
        }

        private static int GetInt(string key, int defaultValue, int minimum, int maximum)
        {
            int parsed;
            if (!int.TryParse(ConfigurationManager.AppSettings[key], out parsed))
            {
                return defaultValue;
            }
            return Math.Max(minimum, Math.Min(maximum, parsed));
        }

        private static bool GetBool(string key, bool defaultValue)
        {
            bool parsed;
            return bool.TryParse(ConfigurationManager.AppSettings[key], out parsed) ? parsed : defaultValue;
        }
    }

    public sealed class NamedFolder
    {
        public NamedFolder(string name, string path)
        {
            Name = name;
            Path = path;
        }

        public string Name { get; private set; }
        public string Path { get; private set; }
    }
}
