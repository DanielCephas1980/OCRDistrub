using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;

namespace CFAMatch_ImageReconciliation
{
    public sealed class FileSystemService
    {
        private readonly AppSettings _settings;

        public FileSystemService(AppSettings settings)
        {
            _settings = settings;
        }

        public void ValidateFolders()
        {
            foreach (NamedFolder folder in GetAllFolders())
            {
                if (!Directory.Exists(folder.Path))
                {
                    throw new DirectoryNotFoundException(folder.Name + " is unavailable: " + folder.Path);
                }

                // Enumerating a single entry verifies that the process can read the directory.
                using (IEnumerator<string> enumerator = Directory.EnumerateFileSystemEntries(folder.Path).GetEnumerator())
                {
                    enumerator.MoveNext();
                }

                ConsoleLogger.Success("Folder accessible: " + folder.Name + " | " + folder.Path);
            }
        }

        public IList<FileLocationState> GetRequiredStates(string newImageName)
        {
            List<FileLocationState> states = new List<FileLocationState>();
            foreach (NamedFolder folder in _settings.RequiredFolders)
            {
                string fullPath = SafeCombine(folder.Path, newImageName);
                states.Add(new FileLocationState(folder, fullPath, IsUsableFile(fullPath)));
            }
            return states;
        }

        public RecoverySource FindRecoverySource(string fileName, bool includeRequiredFolders)
        {
            if (string.IsNullOrWhiteSpace(fileName))
            {
                return null;
            }

            if (includeRequiredFolders)
            {
                foreach (NamedFolder folder in _settings.RequiredFolders)
                {
                    string candidate = SafeCombine(folder.Path, fileName);
                    if (IsUsableFile(candidate))
                    {
                        return new RecoverySource(folder.Name, candidate, fileName);
                    }
                }
            }

            foreach (NamedFolder folder in _settings.RecoveryFolders)
            {
                string candidate = SafeCombine(folder.Path, fileName);
                if (IsUsableFile(candidate))
                {
                    return new RecoverySource(folder.Name, candidate, fileName);
                }
            }

            return null;
        }

        public void CopyAndVerify(string sourcePath, string destinationPath)
        {
            if (!IsUsableFile(sourcePath))
            {
                throw new IOException("Source file is missing, empty, or unreadable: " + sourcePath);
            }

            string destinationDirectory = Path.GetDirectoryName(destinationPath);
            if (string.IsNullOrWhiteSpace(destinationDirectory) || !Directory.Exists(destinationDirectory))
            {
                throw new DirectoryNotFoundException("Destination folder is unavailable: " + destinationDirectory);
            }

            if (File.Exists(destinationPath))
            {
                if (IsUsableFile(destinationPath))
                {
                    return;
                }
                throw new IOException("Destination exists but is not a usable file: " + destinationPath);
            }

            string tempPath = destinationPath + ".reconcile_" + Guid.NewGuid().ToString("N") + ".tmp";
            Exception lastException = null;

            try
            {
                for (int attempt = 1; attempt <= _settings.CopyRetryCount; attempt++)
                {
                    try
                    {
                        File.Copy(sourcePath, tempPath, true);
                        VerifySameSize(sourcePath, tempPath);
                        File.Move(tempPath, destinationPath);
                        VerifySameSize(sourcePath, destinationPath);
                        return;
                    }
                    catch (Exception ex)
                    {
                        lastException = ex;
                        TryDelete(tempPath);
                        if (attempt < _settings.CopyRetryCount)
                        {
                            Thread.Sleep(_settings.CopyRetryDelayMilliseconds);
                        }
                    }
                }
            }
            finally
            {
                TryDelete(tempPath);
            }

            throw new IOException("Copy failed after " + _settings.CopyRetryCount + " attempts: " + destinationPath, lastException);
        }

        public static bool IsUsableFile(string path)
        {
            try
            {
                FileInfo info = new FileInfo(path);
                if (!info.Exists || info.Length <= 0)
                {
                    return false;
                }

                using (FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    return stream.Length > 0;
                }
            }
            catch
            {
                return false;
            }
        }

        public static string SafeCombine(string folder, string fileName)
        {
            if (string.IsNullOrWhiteSpace(fileName))
            {
                throw new ArgumentException("A required image filename is blank.", "fileName");
            }

            string cleanName = Path.GetFileName(fileName.Trim());
            if (!string.Equals(cleanName, fileName.Trim(), StringComparison.Ordinal))
            {
                throw new InvalidDataException("Filename contains path information: " + fileName);
            }

            return Path.Combine(folder, cleanName);
        }

        private IEnumerable<NamedFolder> GetAllFolders()
        {
            foreach (NamedFolder folder in _settings.RequiredFolders) yield return folder;
            foreach (NamedFolder folder in _settings.RecoveryFolders) yield return folder;
        }

        private static void VerifySameSize(string sourcePath, string destinationPath)
        {
            FileInfo source = new FileInfo(sourcePath);
            FileInfo destination = new FileInfo(destinationPath);
            if (!destination.Exists || destination.Length <= 0 || destination.Length != source.Length)
            {
                throw new IOException("Copy verification failed. Source bytes=" + source.Length + ", destination bytes=" + (destination.Exists ? destination.Length : 0));
            }

            using (FileStream stream = new FileStream(destinationPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                if (stream.Length <= 0)
                {
                    throw new IOException("Copied destination cannot be read: " + destinationPath);
                }
            }
        }

        private static void TryDelete(string path)
        {
            try
            {
                if (File.Exists(path)) File.Delete(path);
            }
            catch
            {
                // Best-effort cleanup only.
            }
        }
    }

    public sealed class FileLocationState
    {
        public FileLocationState(NamedFolder folder, string fullPath, bool exists)
        {
            Folder = folder;
            FullPath = fullPath;
            Exists = exists;
        }

        public NamedFolder Folder { get; private set; }
        public string FullPath { get; private set; }
        public bool Exists { get; set; }
    }

    public sealed class RecoverySource
    {
        public RecoverySource(string locationName, string fullPath, string matchedFileName)
        {
            LocationName = locationName;
            FullPath = fullPath;
            MatchedFileName = matchedFileName;
        }

        public string LocationName { get; private set; }
        public string FullPath { get; private set; }
        public string MatchedFileName { get; private set; }
    }
}
