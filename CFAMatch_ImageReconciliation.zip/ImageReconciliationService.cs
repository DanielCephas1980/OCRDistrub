using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace CFAMatch_ImageReconciliation
{
    public sealed class ImageReconciliationService
    {
        private readonly AppSettings _settings;
        private readonly Database _database;
        private readonly FileSystemService _fileSystem;
        private readonly PdfConverter _converter;
        private readonly RunStatistics _statistics;

        public ImageReconciliationService(
            AppSettings settings,
            Database database,
            FileSystemService fileSystem,
            PdfConverter converter,
            RunStatistics statistics)
        {
            _settings = settings;
            _database = database;
            _fileSystem = fileSystem;
            _converter = converter;
            _statistics = statistics;
        }

        public void Process(ClaimImageRecord record, int currentNumber, int totalRecords)
        {
            _statistics.RecordsProcessed++;
            ConsoleLogger.Section("RECORD " + currentNumber + " OF " + totalRecords + " | ID " + record.ID);
            ConsoleLogger.Record(record.ID, "OriginalClearinghouseID: " + ValueOrNull(record.OriginalClearinghouseID));
            ConsoleLogger.Record(record.ID, "OriginalImageName: " + ValueOrNull(record.OriginalImageName));
            ConsoleLogger.Record(record.ID, "NewImageName: " + ValueOrNull(record.NewImageName));
            ConsoleLogger.Record(record.ID, "Current Filler5: " + ValueOrNull(record.Filler5));

            try
            {
                ValidateRecord(record);
                IList<FileLocationState> states = _fileSystem.GetRequiredStates(record.NewImageName);
                PrintRequiredStates(record.ID, states);

                if (states.All(state => state.Exists))
                {
                    _statistics.AlreadyComplete++;
                    _statistics.Complete++;
                    UpdateStatus(record, BuildStatus("COMPLETE", record,
                        "NewImageName was already present and readable in all three required locations."));
                    ConsoleLogger.Success("[ID:" + record.ID + "] Image was already complete.");
                    return;
                }

                RecoverySource source = _fileSystem.FindRecoverySource(record.NewImageName, true);
                bool recoveredUsingOriginal = false;

                if (source == null)
                {
                    source = _fileSystem.FindRecoverySource(record.OriginalImageName, false);
                    recoveredUsingOriginal = source != null;
                }

                if (source == null)
                {
                    _statistics.NotFound++;
                    string message = BuildStatus("NOT FOUND", record,
                        "Neither NewImageName nor OriginalImageName was found as a readable file in any configured required or recovery location.");
                    UpdateStatus(record, message);
                    ConsoleLogger.Warn("[ID:" + record.ID + "] No recovery source was found. This row will be retried on the next run.");
                    return;
                }

                ConsoleLogger.Record(record.ID, "Recovery source: " + source.LocationName + " | " + source.FullPath);

                string workingSource = source.FullPath;
                string temporaryTiff = null;
                try
                {
                    if (RequiresConversion(source.FullPath, record.NewImageName))
                    {
                        temporaryTiff = Path.Combine(Path.GetTempPath(),
                            "CFAMatch_Reconcile_" + record.ID + "_" + Guid.NewGuid().ToString("N") + ".tif");

                        if (_settings.DryRun)
                        {
                            ConsoleLogger.Warn("[ID:" + record.ID + "] DRY RUN: would convert " + source.FullPath + " to TIFF.");
                        }
                        else
                        {
                            ConsoleLogger.Record(record.ID, "Converting source to TIFF: " + source.FullPath);
                            _converter.ConvertToTiff(source.FullPath, temporaryTiff);
                            if (!FileSystemService.IsUsableFile(temporaryTiff))
                            {
                                throw new IOException("Converted TIFF is missing, empty, or unreadable: " + temporaryTiff);
                            }
                            _statistics.PdfConversions += Path.GetExtension(source.FullPath)
                                .Equals(".pdf", StringComparison.OrdinalIgnoreCase) ? 1 : 0;
                            workingSource = temporaryTiff;
                            ConsoleLogger.Success("[ID:" + record.ID + "] TIFF conversion completed.");
                        }
                    }

                    int copiesForRecord = 0;
                    foreach (FileLocationState missingState in states.Where(state => !state.Exists))
                    {
                        if (_settings.DryRun)
                        {
                            ConsoleLogger.Warn("[ID:" + record.ID + "] DRY RUN: would copy to " + missingState.FullPath);
                            continue;
                        }

                        ConsoleLogger.Record(record.ID, "Copying to missing location: " + missingState.FullPath);
                        _fileSystem.CopyAndVerify(workingSource, missingState.FullPath);
                        missingState.Exists = true;
                        copiesForRecord++;
                        _statistics.FilesCopied++;
                        ConsoleLogger.Success("[ID:" + record.ID + "] Copy verified: " + missingState.FullPath);
                    }

                    if (_settings.DryRun)
                    {
                        ConsoleLogger.Warn("[ID:" + record.ID + "] DRY RUN: database status was not changed.");
                        return;
                    }

                    IList<FileLocationState> finalStates = _fileSystem.GetRequiredStates(record.NewImageName);
                    PrintRequiredStates(record.ID, finalStates);
                    if (!finalStates.All(state => state.Exists))
                    {
                        throw new IOException("One or more required destination files are still missing or unreadable after repair.");
                    }

                    if (recoveredUsingOriginal)
                    {
                        _statistics.RecoveredUsingOriginalImageName++;
                    }
                    else
                    {
                        _statistics.RecoveredUsingNewImageName++;
                    }

                    _statistics.Complete++;
                    string details = "Recovered from " + source.LocationName + " using " +
                        (recoveredUsingOriginal ? "OriginalImageName" : "NewImageName") +
                        ". Files copied: " + copiesForRecord +
                        ". NewImageName is now present and readable in all three required locations.";
                    UpdateStatus(record, BuildStatus("COMPLETE", record, details));
                    ConsoleLogger.Success("[ID:" + record.ID + "] Reconciliation completed successfully.");
                }
                finally
                {
                    TryDelete(temporaryTiff);
                }
            }
            catch (Exception ex)
            {
                _statistics.Errors++;
                string errorMessage = BuildStatus("ERROR", record,
                    ex.GetType().Name + ": " + ex.Message);

                try
                {
                    UpdateStatus(record, errorMessage);
                }
                catch (Exception databaseException)
                {
                    ConsoleLogger.Error("[ID:" + record.ID + "] Could not save ERROR status: " + databaseException);
                }

                ConsoleLogger.Error("[ID:" + record.ID + "] " + ex);
            }
        }

        private void UpdateStatus(ClaimImageRecord record, string newStatus)
        {
            string finalStatus = AddPreviousStatus(newStatus, record.Filler5);
            if (_settings.DryRun)
            {
                ConsoleLogger.Warn("[ID:" + record.ID + "] DRY RUN: would set Filler5 to: " + newStatus.Replace(Environment.NewLine, " | "));
                return;
            }

            _database.UpdateFiller5(record.ID, finalStatus);
            _statistics.DatabaseUpdates++;
            ConsoleLogger.Record(record.ID, "Filler5 updated using identity ID.");
        }

        private static string BuildStatus(string status, ClaimImageRecord record, string details)
        {
            StringBuilder builder = new StringBuilder();
            builder.Append(status).Append(": ").Append(details).AppendLine();
            builder.Append("Checked: ").Append(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")).AppendLine();
            builder.Append("ID: ").Append(record.ID).AppendLine();
            builder.Append("OriginalClearinghouseID: ").Append(ValueOrNull(record.OriginalClearinghouseID)).AppendLine();
            builder.Append("OriginalImageName: ").Append(ValueOrNull(record.OriginalImageName)).AppendLine();
            builder.Append("NewImageName: ").Append(ValueOrNull(record.NewImageName));
            return builder.ToString();
        }

        private static string AddPreviousStatus(string currentStatus, string previousStatus)
        {
            if (string.IsNullOrWhiteSpace(previousStatus))
            {
                return currentStatus;
            }

            const int maximumPreviousCharacters = 8000;
            string prior = previousStatus.Length > maximumPreviousCharacters
                ? previousStatus.Substring(0, maximumPreviousCharacters)
                : previousStatus;

            return currentStatus + Environment.NewLine + Environment.NewLine +
                   "PREVIOUS STATUS:" + Environment.NewLine + prior;
        }

        private static bool RequiresConversion(string sourcePath, string newImageName)
        {
            string sourceExtension = Path.GetExtension(sourcePath) ?? string.Empty;
            string destinationExtension = Path.GetExtension(newImageName) ?? string.Empty;

            if (!destinationExtension.Equals(".tif", StringComparison.OrdinalIgnoreCase) &&
                !destinationExtension.Equals(".tiff", StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidDataException("NewImageName must have a .tif or .tiff extension: " + newImageName);
            }

            return !sourceExtension.Equals(".tif", StringComparison.OrdinalIgnoreCase) &&
                   !sourceExtension.Equals(".tiff", StringComparison.OrdinalIgnoreCase);
        }

        private static void ValidateRecord(ClaimImageRecord record)
        {
            if (record.ID <= 0) throw new InvalidDataException("ID is invalid.");
            if (string.IsNullOrWhiteSpace(record.NewImageName)) throw new InvalidDataException("NewImageName is blank.");
            FileSystemService.SafeCombine(Path.GetTempPath(), record.NewImageName);
            if (!string.IsNullOrWhiteSpace(record.OriginalImageName))
            {
                FileSystemService.SafeCombine(Path.GetTempPath(), record.OriginalImageName);
            }
        }

        private static void PrintRequiredStates(int id, IEnumerable<FileLocationState> states)
        {
            foreach (FileLocationState state in states)
            {
                ConsoleLogger.Record(id, (state.Exists ? "FOUND   " : "MISSING ") + state.Folder.Name + " | " + state.FullPath);
            }
        }

        private static string ValueOrNull(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? "<NULL>" : value;
        }

        private static void TryDelete(string path)
        {
            if (string.IsNullOrWhiteSpace(path)) return;
            try { if (File.Exists(path)) File.Delete(path); } catch { }
        }
    }
}
