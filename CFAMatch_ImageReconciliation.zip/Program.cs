using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace CFAMatch_ImageReconciliation
{
    internal static class Program
    {
        private static int Main(string[] args)
        {
            RunStatistics statistics = new RunStatistics { Started = DateTime.Now };
            Stopwatch stopwatch = Stopwatch.StartNew();

            try
            {
                AppSettings settings = AppSettings.Load();
                Console.Title = settings.ApplicationName;
                ConsoleLogger.Banner(settings.ApplicationName, settings.ApplicationVersion, settings.DryRun);

                Database database = new Database(settings.ConnectionString);
                FileSystemService fileSystem = new FileSystemService(settings);
                PdfConverter converter = new PdfConverter(settings.PdfRenderDpi);

                ConsoleLogger.Section("STARTUP VALIDATION");
                database.ValidateConnection();
                ConsoleLogger.Success("SQL connection successful.");

                if (settings.ValidateAllFoldersAtStartup)
                {
                    fileSystem.ValidateFolders();
                }
                else
                {
                    ConsoleLogger.Warn("Startup folder validation is disabled in App.config.");
                }

                ConsoleLogger.Section("READING PENDING CROSSWALK RECORDS");
                IList<ClaimImageRecord> records = database.GetPendingRecords();
                statistics.RecordsRead = records.Count;
                ConsoleLogger.Info("Pending records found: " + records.Count);

                ImageReconciliationService service = new ImageReconciliationService(
                    settings, database, fileSystem, converter, statistics);

                for (int index = 0; index < records.Count; index++)
                {
                    service.Process(records[index], index + 1, records.Count);
                }

                statistics.Finished = DateTime.Now;
                statistics.Print();

                if (statistics.Errors > 0)
                {
                    ConsoleLogger.Warn("Application completed with one or more record-level errors.");
                    return 2;
                }

                ConsoleLogger.Success("Application completed successfully.");
                return 0;
            }
            catch (Exception ex)
            {
                statistics.Errors++;
                statistics.Finished = DateTime.Now;
                ConsoleLogger.Error("Fatal application error: " + ex);
                statistics.Print();
                return 1;
            }
            finally
            {
                stopwatch.Stop();
                ConsoleLogger.Info("Process exit time: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") +
                                   " | Total elapsed: " + stopwatch.Elapsed);
            }
        }
    }
}
