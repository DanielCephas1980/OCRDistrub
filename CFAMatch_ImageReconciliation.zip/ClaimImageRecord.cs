namespace CFAMatch_ImageReconciliation
{
    public sealed class ClaimImageRecord
    {
        public int ID { get; set; }
        public string OriginalClearinghouseID { get; set; }
        public string OriginalImageName { get; set; }
        public string NewImageName { get; set; }
        public string Filler5 { get; set; }
    }
}
