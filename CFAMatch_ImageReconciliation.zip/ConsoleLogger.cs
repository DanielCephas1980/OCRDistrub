using System;

namespace CFAMatch_ImageReconciliation
{
    public static class ConsoleLogger
    {
        private static readonly object SyncRoot = new object();

        public static void Banner(string applicationName, string version, bool dryRun)
        {
            Line(new string('=', 78));
            Line(applicationName);
            Line("Version: " + version);
            Line("Started: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            if (dryRun)
            {
                Warn("DRY RUN IS ENABLED - no files or database rows will be changed.");
            }
            Line(new string('=', 78));
        }

        public static void Section(string text)
        {
            Line(string.Empty);
            Line(new string('-', 78));
            Line(text);
            Line(new string('-', 78));
        }

        public static void Info(string message) { Write("INFO", message, ConsoleColor.Gray); }
        public static void Success(string message) { Write("SUCCESS", message, ConsoleColor.Green); }
        public static void Warn(string message) { Write("WARNING", message, ConsoleColor.Yellow); }
        public static void Error(string message) { Write("ERROR", message, ConsoleColor.Red); }
        public static void Record(int id, string message) { Write("ID:" + id, message, ConsoleColor.Cyan); }

        public static void Line(string message)
        {
            lock (SyncRoot)
            {
                Console.WriteLine(message);
            }
        }

        private static void Write(string level, string message, ConsoleColor color)
        {
            lock (SyncRoot)
            {
                ConsoleColor original = Console.ForegroundColor;
                try
                {
                    Console.ForegroundColor = color;
                    Console.Write("[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] [" + level + "] ");
                    Console.ForegroundColor = original;
                    Console.WriteLine(message);
                }
                finally
                {
                    Console.ForegroundColor = original;
                }
            }
        }
    }
}
