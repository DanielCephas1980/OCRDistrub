using System;

namespace CFAMatch_ImageReconciliation
{
    public sealed class RunStatistics
    {
        public int RecordsRead { get; set; }
        public int RecordsProcessed { get; set; }
        public int AlreadyComplete { get; set; }
        public int RecoveredUsingNewImageName { get; set; }
        public int RecoveredUsingOriginalImageName { get; set; }
        public int PdfConversions { get; set; }
        public int FilesCopied { get; set; }
        public int Complete { get; set; }
        public int NotFound { get; set; }
        public int Errors { get; set; }
        public int DatabaseUpdates { get; set; }
        public DateTime Started { get; set; }
        public DateTime Finished { get; set; }

        public void Print()
        {
            ConsoleLogger.Section("FINAL SUMMARY");
            ConsoleLogger.Line("Records read                    : " + RecordsRead);
            ConsoleLogger.Line("Records processed               : " + RecordsProcessed);
            ConsoleLogger.Line("Already complete                : " + AlreadyComplete);
            ConsoleLogger.Line("Recovered using NewImageName    : " + RecoveredUsingNewImageName);
            ConsoleLogger.Line("Recovered using Original name   : " + RecoveredUsingOriginalImageName);
            ConsoleLogger.Line("PDF to TIFF conversions         : " + PdfConversions);
            ConsoleLogger.Line("Files copied                    : " + FilesCopied);
            ConsoleLogger.Line("COMPLETE                        : " + Complete);
            ConsoleLogger.Line("NOT FOUND                       : " + NotFound);
            ConsoleLogger.Line("ERROR                           : " + Errors);
            ConsoleLogger.Line("Database updates                : " + DatabaseUpdates);
            ConsoleLogger.Line("Elapsed                         : " + (Finished - Started));
        }
    }
}
