using PdfiumViewer;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;

namespace CFAMatch_ImageReconciliation
{
    public sealed class PdfConverter
    {
        private readonly int _renderDpi;

        public PdfConverter(int renderDpi)
        {
            _renderDpi = renderDpi;
        }

        public void ConvertToTiff(string sourcePath, string destinationTiffPath)
        {
            string extension = Path.GetExtension(sourcePath) ?? string.Empty;

            if (extension.Equals(".pdf", StringComparison.OrdinalIgnoreCase))
            {
                ConvertPdfToMultipageTiff(sourcePath, destinationTiffPath);
                return;
            }

            ConvertImageToTiff(sourcePath, destinationTiffPath);
        }

        private void ConvertPdfToMultipageTiff(string pdfPath, string destinationTiffPath)
        {
            List<Bitmap> pages = new List<Bitmap>();
            try
            {
                using (PdfDocument document = PdfDocument.Load(pdfPath))
                {
                    if (document.PageCount <= 0)
                    {
                        throw new InvalidDataException("PDF has no pages: " + pdfPath);
                    }

                    for (int pageIndex = 0; pageIndex < document.PageCount; pageIndex++)
                    {
                        SizeF pageSize = document.PageSizes[pageIndex];
                        int width = Math.Max(1, (int)Math.Ceiling(pageSize.Width / 72f * _renderDpi));
                        int height = Math.Max(1, (int)Math.Ceiling(pageSize.Height / 72f * _renderDpi));

                        using (Image rendered = document.Render(
                            pageIndex,
                            width,
                            height,
                            _renderDpi,
                            _renderDpi,
                            PdfRenderFlags.Annotations | PdfRenderFlags.ForPrinting))
                        {
                            pages.Add(ConvertToBlackAndWhite(rendered));
                        }
                    }
                }

                SaveMultipageTiff(pages, destinationTiffPath);
            }
            finally
            {
                foreach (Bitmap page in pages)
                {
                    page.Dispose();
                }
            }
        }

        private static void ConvertImageToTiff(string sourcePath, string destinationTiffPath)
        {
            using (Image image = Image.FromFile(sourcePath))
            using (Bitmap blackAndWhite = ConvertToBlackAndWhite(image))
            {
                SaveMultipageTiff(new List<Bitmap> { blackAndWhite }, destinationTiffPath);
            }
        }

        private static Bitmap ConvertToBlackAndWhite(Image source)
        {
            using (Bitmap rgb = new Bitmap(source.Width, source.Height, PixelFormat.Format24bppRgb))
            {
                rgb.SetResolution(
                    source.HorizontalResolution > 0 ? source.HorizontalResolution : 300,
                    source.VerticalResolution > 0 ? source.VerticalResolution : 300);

                using (Graphics graphics = Graphics.FromImage(rgb))
                {
                    graphics.Clear(Color.White);
                    graphics.DrawImage(source, new Rectangle(0, 0, rgb.Width, rgb.Height));
                }

                Bitmap result = new Bitmap(rgb.Width, rgb.Height, PixelFormat.Format1bppIndexed);
                result.SetResolution(rgb.HorizontalResolution, rgb.VerticalResolution);

                Rectangle rectangle = new Rectangle(0, 0, rgb.Width, rgb.Height);
                BitmapData sourceData = rgb.LockBits(rectangle, ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
                BitmapData destinationData = result.LockBits(rectangle, ImageLockMode.WriteOnly, PixelFormat.Format1bppIndexed);

                try
                {
                    int sourceStride = Math.Abs(sourceData.Stride);
                    int destinationStride = Math.Abs(destinationData.Stride);
                    byte[] sourceBytes = new byte[sourceStride * rgb.Height];
                    byte[] destinationBytes = Enumerable.Repeat((byte)0xFF, destinationStride * rgb.Height).ToArray();
                    Marshal.Copy(sourceData.Scan0, sourceBytes, 0, sourceBytes.Length);

                    const int threshold = 210;
                    for (int y = 0; y < rgb.Height; y++)
                    {
                        int sourceRow = sourceData.Stride > 0 ? y * sourceStride : (rgb.Height - 1 - y) * sourceStride;
                        int destinationRow = destinationData.Stride > 0 ? y * destinationStride : (rgb.Height - 1 - y) * destinationStride;

                        for (int x = 0; x < rgb.Width; x++)
                        {
                            int pixel = sourceRow + (x * 3);
                            int blue = sourceBytes[pixel];
                            int green = sourceBytes[pixel + 1];
                            int red = sourceBytes[pixel + 2];
                            int luminance = (red * 299 + green * 587 + blue * 114) / 1000;

                            if (luminance < threshold)
                            {
                                int byteIndex = destinationRow + (x >> 3);
                                int bitMask = 0x80 >> (x & 7);
                                destinationBytes[byteIndex] = (byte)(destinationBytes[byteIndex] & ~bitMask);
                            }
                        }
                    }

                    Marshal.Copy(destinationBytes, 0, destinationData.Scan0, destinationBytes.Length);
                }
                catch
                {
                    result.Dispose();
                    throw;
                }
                finally
                {
                    rgb.UnlockBits(sourceData);
                    result.UnlockBits(destinationData);
                }

                return result;
            }
        }

        private static void SaveMultipageTiff(IList<Bitmap> pages, string outputPath)
        {
            if (pages == null || pages.Count == 0)
            {
                throw new ArgumentException("At least one page is required to create a TIFF.", "pages");
            }

            ImageCodecInfo tiffCodec = ImageCodecInfo.GetImageEncoders()
                .FirstOrDefault(codec => codec.FormatID == ImageFormat.Tiff.Guid);

            if (tiffCodec == null)
            {
                throw new InvalidOperationException("The TIFF image encoder is unavailable.");
            }

            using (EncoderParameters firstPageParameters = CreateEncoderParameters(EncoderValue.MultiFrame))
            {
                pages[0].Save(outputPath, tiffCodec, firstPageParameters);
            }

            try
            {
                for (int index = 1; index < pages.Count; index++)
                {
                    using (EncoderParameters nextPageParameters = CreateEncoderParameters(EncoderValue.FrameDimensionPage))
                    {
                        pages[0].SaveAdd(pages[index], nextPageParameters);
                    }
                }

                using (EncoderParameters flushParameters = new EncoderParameters(1))
                {
                    flushParameters.Param[0] = new EncoderParameter(Encoder.SaveFlag, (long)EncoderValue.Flush);
                    pages[0].SaveAdd(flushParameters);
                }
            }
            catch
            {
                try { if (File.Exists(outputPath)) File.Delete(outputPath); } catch { }
                throw;
            }
        }

        private static EncoderParameters CreateEncoderParameters(EncoderValue saveFlag)
        {
            EncoderParameters parameters = new EncoderParameters(2);
            parameters.Param[0] = new EncoderParameter(Encoder.SaveFlag, (long)saveFlag);
            parameters.Param[1] = new EncoderParameter(Encoder.Compression, (long)EncoderValue.CompressionCCITT4);
            return parameters;
        }
    }
}
