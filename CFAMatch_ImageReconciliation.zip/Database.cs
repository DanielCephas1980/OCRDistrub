using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace CFAMatch_ImageReconciliation
{
    public sealed class Database
    {
        private readonly string _connectionString;

        public Database(string connectionString)
        {
            _connectionString = connectionString;
        }

        public void ValidateConnection()
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("SELECT 1", connection))
                {
                    command.CommandTimeout = 60;
                    command.ExecuteScalar();
                }
            }
        }

        public IList<ClaimImageRecord> GetPendingRecords()
        {
            const string sql = @"
SELECT
    ID,
    OriginalClearinghouseID,
    OriginalImageName,
    NewImageName,
    Filler5
FROM dbo.tbRefUserCreatedClmImageCrosswalk
WHERE Filler5 IS NULL
   OR Filler5 LIKE 'NOT FOUND:%'
   OR Filler5 LIKE 'ERROR:%'
ORDER BY ID;";

            List<ClaimImageRecord> records = new List<ClaimImageRecord>();

            using (SqlConnection connection = new SqlConnection(_connectionString))
            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                command.CommandTimeout = 300;
                connection.Open();

                using (SqlDataReader reader = command.ExecuteReader(CommandBehavior.SequentialAccess))
                {
                    int idOrdinal = reader.GetOrdinal("ID");
                    int clearinghouseOrdinal = reader.GetOrdinal("OriginalClearinghouseID");
                    int originalImageOrdinal = reader.GetOrdinal("OriginalImageName");
                    int newImageOrdinal = reader.GetOrdinal("NewImageName");
                    int fillerOrdinal = reader.GetOrdinal("Filler5");

                    while (reader.Read())
                    {
                        records.Add(new ClaimImageRecord
                        {
                            ID = reader.GetInt32(idOrdinal),
                            OriginalClearinghouseID = ReadString(reader, clearinghouseOrdinal),
                            OriginalImageName = ReadString(reader, originalImageOrdinal),
                            NewImageName = ReadString(reader, newImageOrdinal),
                            Filler5 = ReadString(reader, fillerOrdinal)
                        });
                    }
                }
            }

            return records;
        }

        public void UpdateFiller5(int id, string message)
        {
            const string sql = @"
UPDATE dbo.tbRefUserCreatedClmImageCrosswalk
SET Filler5 = @Filler5
WHERE ID = @ID;

IF @@ROWCOUNT <> 1
    THROW 50001, 'Expected to update exactly one crosswalk row.', 1;";

            using (SqlConnection connection = new SqlConnection(_connectionString))
            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                command.CommandTimeout = 60;
                command.Parameters.Add("@ID", SqlDbType.Int).Value = id;
                command.Parameters.Add("@Filler5", SqlDbType.VarChar, -1).Value =
                    string.IsNullOrEmpty(message) ? (object)DBNull.Value : message;
                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        private static string ReadString(SqlDataReader reader, int ordinal)
        {
            return reader.IsDBNull(ordinal) ? null : Convert.ToString(reader.GetValue(ordinal));
        }
    }
}
