using System;
using System.IO;
using System.Text;
using NPOI.SS.UserModel;
using PdfSharp.Pdf;
using TheArtOfDev.HtmlRenderer.PdfSharp;
using CFAMatch.PdfMerger;

namespace CFAMatch.PdfMerger.Converters
{
    /// <summary>
    /// Converts an Excel workbook (.xls or .xlsx - NPOI auto-detects the format from the
    /// stream) to a PDF by rendering each worksheet as an HTML table and running that
    /// through the same HtmlRenderer.PdfSharp pipeline used for Word. Landscape
    /// orientation is used since spreadsheets are typically wider than they are tall.
    ///
    /// This is a plain-data rendering, not a pixel-perfect reproduction of Excel's print
    /// layout (no cell merges beyond basic colspan, no charts/images, no conditional
    /// formatting). That trade-off is what lets this run on free, pure-managed
    /// libraries with no Excel/COM interop and no native binaries.
    /// </summary>
    public static class ExcelToPdfConverter
    {
        public static void ConvertExcelToPdf(string excelPath, string pdfPath)
        {
            Logger.Debug($"Reading workbook: {excelPath}");
            string html;
            using (var fileStream = new FileStream(excelPath, FileMode.Open, FileAccess.Read, FileShare.Read))
            using (IWorkbook workbook = WorkbookFactory.Create(fileStream))
            {
                html = BuildHtml(workbook, Path.GetFileNameWithoutExtension(excelPath));
            }

            Logger.Debug($"Rendering HTML to PDF: {pdfPath}");
            var config = new PdfGenerateConfig
            {
                PageSize = PdfSharp.PageSize.A4,
                PageOrientation = PdfSharp.PageOrientation.Landscape
            };
            config.SetMargins(20);

            using (PdfDocument pdfDocument = PdfGenerator.GeneratePdf(html, config))
            {
                pdfDocument.Save(pdfPath);
            }
        }

        private static string BuildHtml(IWorkbook workbook, string documentTitle)
        {
            var sb = new StringBuilder();
            sb.Append("<html><head><meta charset='utf-8'/><style>");
            sb.Append("body{font-family:Arial,sans-serif;} ");
            sb.Append("h2{font-size:14px;margin:10px 0 4px 0;} ");
            sb.Append("table{border-collapse:collapse;width:100%;margin-bottom:16px;} ");
            sb.Append("td,th{border:1px solid #999999;padding:3px 5px;font-size:9px;text-align:left;vertical-align:top;}");
            sb.Append("</style></head><body>");

            int sheetCount = workbook.NumberOfSheets;
            for (int sheetIndex = 0; sheetIndex < sheetCount; sheetIndex++)
            {
                ISheet sheet = workbook.GetSheetAt(sheetIndex);
                sb.Append("<h2>").Append(Escape(documentTitle)).Append(" - ").Append(Escape(sheet.SheetName)).Append("</h2>");

                if (sheet.PhysicalNumberOfRows == 0)
                {
                    sb.Append("<p><em>(empty worksheet)</em></p>");
                    continue;
                }

                sb.Append("<table>");
                int firstRow = sheet.FirstRowNum;
                int lastRow = sheet.LastRowNum;

                for (int rowIndex = firstRow; rowIndex <= lastRow; rowIndex++)
                {
                    IRow row = sheet.GetRow(rowIndex);
                    sb.Append("<tr>");

                    if (row == null)
                    {
                        sb.Append("<td>&nbsp;</td>");
                    }
                    else
                    {
                        short firstCell = row.FirstCellNum;
                        short lastCell = row.LastCellNum;
                        if (firstCell < 0) firstCell = 0;

                        for (int cellIndex = firstCell; cellIndex < lastCell; cellIndex++)
                        {
                            ICell cell = row.GetCell(cellIndex);
                            sb.Append("<td>").Append(Escape(GetCellText(cell))).Append("</td>");
                        }

                        if (lastCell <= firstCell)
                        {
                            sb.Append("<td>&nbsp;</td>");
                        }
                    }

                    sb.Append("</tr>");
                }

                sb.Append("</table>");
            }

            sb.Append("</body></html>");
            return sb.ToString();
        }

        private static string GetCellText(ICell cell)
        {
            if (cell == null) return string.Empty;

            switch (cell.CellType)
            {
                case CellType.String:
                    return cell.StringCellValue;
                case CellType.Numeric:
                    return DateUtil.IsCellDateFormatted(cell)
                        ? cell.DateCellValue?.ToString("yyyy-MM-dd") ?? string.Empty
                        : cell.NumericCellValue.ToString(System.Globalization.CultureInfo.InvariantCulture);
                case CellType.Boolean:
                    return cell.BooleanCellValue.ToString();
                case CellType.Formula:
                    return TryGetFormulaResultText(cell);
                case CellType.Blank:
                default:
                    // NPOI's CellType has an internal-use-only "unset" sentinel (named
                    // Unknown in NPOI <= 2.7.5, renamed to _None in 2.7.6+) that should
                    // never appear for a real cell returned from the API. Falling through
                    // to the default case here covers it either way without depending on
                    // a member name that changed between NPOI versions.
                    return string.Empty;
            }
        }

        private static string TryGetFormulaResultText(ICell cell)
        {
            try
            {
                switch (cell.CachedFormulaResultType)
                {
                    case CellType.String:
                        return cell.StringCellValue;
                    case CellType.Numeric:
                        return cell.NumericCellValue.ToString(System.Globalization.CultureInfo.InvariantCulture);
                    case CellType.Boolean:
                        return cell.BooleanCellValue.ToString();
                    default:
                        return cell.ToString();
                }
            }
            catch
            {
                return cell.ToString();
            }
        }

        private static string Escape(string text)
        {
            if (string.IsNullOrEmpty(text)) return string.Empty;
            return text
                .Replace("&", "&amp;")
                .Replace("<", "&lt;")
                .Replace(">", "&gt;");
        }
    }
}
