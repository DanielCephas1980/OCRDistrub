using System.Collections.Generic;
using System.Linq;

namespace CFAMatch.PdfMerger
{
    /// <summary>
    /// All the files that share a common submission prefix (GroupKey), in the order
    /// they should be merged. IsValid/InvalidReason let the grouping and validation
    /// step explain up front why a group is headed for Exclude, before any conversion
    /// is even attempted.
    /// </summary>
    public sealed class SubmissionGroup
    {
        public string GroupKey { get; }
        public List<SubmissionFile> Files { get; }
        public bool IsValid { get; private set; } = true;
        public List<string> InvalidReasons { get; } = new List<string>();

        public SubmissionGroup(string groupKey, IEnumerable<SubmissionFile> files)
        {
            GroupKey = groupKey;
            Files = files.ToList();
        }

        public void MarkInvalid(string reason)
        {
            IsValid = false;
            InvalidReasons.Add(reason);
        }

        public IEnumerable<string> AllFilePaths => Files.Select(f => f.FullPath);
    }
}
