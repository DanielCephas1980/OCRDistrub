using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;

namespace CFAMatch.PdfMerger
{
    /// <summary>
    /// Resolves App.config into concrete, ready-to-use paths and settings for this run.
    /// All CFA-vs-NCAS branching lives here in one place: Mode picks the output prefix,
    /// and (when Mode=NCAS) rewrites the literal "CFA" segment of BasePath to "NCAS".
    /// </summary>
    public sealed class AppSettings
    {
        public string Mode { get; private set; }
        public string Prefix { get; private set; }

        public string SourceDirectory { get; private set; }
        public string OutputDirectory { get; private set; }
        public string ProcessedDirectory { get; private set; }
        public string ExcludeDirectory { get; private set; }
        public string TempDirectory { get; private set; }
        public string LogDirectory { get; private set; }

        public HashSet<string> AllowedExtensions { get; private set; }
        public bool VerboseLogging { get; private set; }

        public static AppSettings Load()
        {
            var mode = ReadSetting("Mode", "CFA").Trim().ToUpperInvariant();
            if (mode != "CFA" && mode != "NCAS")
            {
                throw new ConfigurationErrorsException(
                    $"App.config Mode value '{mode}' is invalid. Expected 'CFA' or 'NCAS'.");
            }

            var configuredBasePath = ReadSetting("BasePath", required: true);

            string basePath;
            if (mode == "NCAS")
            {
                if (configuredBasePath.IndexOf("CFA", StringComparison.OrdinalIgnoreCase) < 0)
                {
                    throw new ConfigurationErrorsException(
                        "Mode is NCAS but App.config BasePath does not contain the literal text " +
                        "'CFA' anywhere, so there is nothing to substitute with 'NCAS'. " +
                        $"BasePath was: {configuredBasePath}");
                }
                basePath = ReplaceCaseInsensitive(configuredBasePath, "CFA", "NCAS");
            }
            else
            {
                basePath = configuredBasePath;
            }

            var settings = new AppSettings
            {
                Mode = mode,
                Prefix = mode + "_",
                SourceDirectory = basePath,
                OutputDirectory = Path.Combine(basePath, ReadSetting("OutputFolderName", "Output")),
                ProcessedDirectory = Path.Combine(basePath, ReadSetting("ProcessedFolderName", "Processed")),
                ExcludeDirectory = Path.Combine(basePath, ReadSetting("ExcludeFolderName", "Exclude")),
                TempDirectory = Path.Combine(basePath, ReadSetting("TempFolderName", "Temp")),
                LogDirectory = Path.Combine(basePath, ReadSetting("LogFolderName", "Logs")),
                VerboseLogging = bool.TryParse(ReadSetting("VerboseLogging", "false"), out var v) && v
            };

            var extensions = ReadSetting("AllowedExtensions", ".pdf,.docx,.xlsx,.xls,.jpg,.jpeg,.png,.bmp,.gif,.tif,.tiff")
                .Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(e => e.Trim())
                .Where(e => e.Length > 0)
                .Select(e => e.StartsWith(".") ? e : "." + e);
            settings.AllowedExtensions = new HashSet<string>(extensions, StringComparer.OrdinalIgnoreCase);

            return settings;
        }

        private static string ReplaceCaseInsensitive(string input, string search, string replacement)
        {
            var index = input.IndexOf(search, StringComparison.OrdinalIgnoreCase);
            if (index < 0) return input;
            return input.Substring(0, index) + replacement + input.Substring(index + search.Length);
        }

        private static string ReadSetting(string key, string defaultValue = null, bool required = false)
        {
            var value = ConfigurationManager.AppSettings[key];
            if (string.IsNullOrWhiteSpace(value))
            {
                if (required)
                {
                    throw new ConfigurationErrorsException($"App.config is missing required appSetting '{key}'.");
                }
                return defaultValue;
            }
            return value;
        }
    }
}
