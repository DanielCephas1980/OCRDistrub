using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Threading;
using CFAMatch.PdfMerger.Converters;

namespace CFAMatch.PdfMerger
{
    public enum ProcessResult
    {
        Success,
        Excluded
    }

    /// <summary>
    /// Runs one submission group end-to-end.
    ///
    /// Supported behavior:
    ///   - A normal multi-file group (_0, _1, _2, ...) is converted and merged in
    ///     document-number order.
    ///   - A single-file group (for example, only _0) is still processed and produces
    ///     the normal CFA_/NCAS_ output PDF. It does not wait for an _1 file.
    ///   - A .zip file occupies the same position in the outer group as its numeric
    ///     suffix. Its file contents are extracted into an isolated temp folder,
    ///     converted individually, and merged into ONE temporary PDF representing that
    ///     ZIP. That temporary PDF then participates in the normal outer-group merge.
    ///
    /// If any source file, ZIP entry, conversion, or merge fails, the entire original
    /// submission group is moved to Exclude and any partial output is removed.
    /// </summary>
    public sealed class GroupProcessor
    {
        private readonly AppSettings _settings;

        public GroupProcessor(AppSettings settings)
        {
            _settings = settings;
        }

        public ProcessResult Process(SubmissionGroup group)
        {
            if (!group.IsValid)
            {
                Logger.Warn($"Group '{group.GroupKey}' failed validation: {string.Join(" | ", group.InvalidReasons)}");
                ExcludeGroup(group);
                return ProcessResult.Excluded;
            }

            string runFolder = Path.Combine(_settings.TempDirectory, Guid.NewGuid().ToString("N"));
            var orderedPdfPaths = new List<string>();

            try
            {
                Directory.CreateDirectory(runFolder);
                Logger.Info($"Processing group '{group.GroupKey}' ({group.Files.Count} file(s)): " +
                            string.Join(", ", group.Files.ConvertAll(f => f.FileName)));

                if (group.Files.Count == 1)
                {
                    Logger.Info($"Group '{group.GroupKey}' contains a single source file; processing it immediately (no _1 file is required).");
                }

                foreach (var file in group.Files)
                {
                    orderedPdfPaths.Add(ResolveToPdf(file, runFolder));
                }

                string mergedFileName = $"{_settings.Prefix}{group.GroupKey}.pdf";
                string mergedOutputPath = Path.Combine(_settings.OutputDirectory, mergedFileName);

                Logger.Info($"Writing {orderedPdfPaths.Count} PDF source(s) into '{mergedFileName}'");
                PdfMergerService.Merge(orderedPdfPaths, mergedOutputPath);
                Logger.Info($"Merged PDF written: {mergedOutputPath}");

                MoveFiles(group.AllFilePaths, _settings.ProcessedDirectory);
                Logger.Info($"Group '{group.GroupKey}' complete - {group.Files.Count} original source file(s) moved to Processed.");

                return ProcessResult.Success;
            }
            catch (Exception ex)
            {
                Logger.Error($"Group '{group.GroupKey}' failed - routing all {group.Files.Count} original source file(s) to Exclude", ex);
                TryDeletePartialOutput(group);
                ExcludeGroup(group);
                return ProcessResult.Excluded;
            }
            finally
            {
                CleanupTempFolder(runFolder);
            }
        }

        private string ResolveToPdf(SubmissionFile file, string runFolder)
        {
            if (file.Extension.Equals(".zip", StringComparison.OrdinalIgnoreCase))
            {
                return ConvertZipToPdf(file.FullPath, runFolder);
            }

            return ResolveFileToPdf(file.FullPath, runFolder);
        }

        private string ResolveFileToPdf(string sourcePath, string runFolder)
        {
            string ext = Path.GetExtension(sourcePath).ToLowerInvariant();

            if (ext == ".pdf")
            {
                return sourcePath;
            }

            if (ext == ".zip")
            {
                // Outer ZIPs are supported. A ZIP nested inside another ZIP is rejected
                // deliberately so there is no ambiguous recursive archive behavior.
                throw new NotSupportedException(
                    $"Nested ZIP files are not supported: '{Path.GetFileName(sourcePath)}'.");
            }

            string convertedPath = Path.Combine(
                runFolder,
                $"{Path.GetFileNameWithoutExtension(sourcePath)}_{Guid.NewGuid():N}.pdf");

            Logger.Info($"Converting '{Path.GetFileName(sourcePath)}' -> '{Path.GetFileName(convertedPath)}'");

            switch (ext)
            {
                case ".docx":
                    WordToPdfConverter.ConvertDocxToPdf(sourcePath, convertedPath);
                    break;
                case ".xlsx":
                case ".xls":
                    ExcelToPdfConverter.ConvertExcelToPdf(sourcePath, convertedPath);
                    break;
                case ".jpg":
                case ".jpeg":
                case ".png":
                case ".bmp":
                case ".gif":
                case ".tif":
                case ".tiff":
                    ImageToPdfConverter.ConvertImageToPdf(sourcePath, convertedPath, runFolder);
                    break;
                default:
                    throw new NotSupportedException(
                        $"No converter is registered for extension '{ext}' on file '{Path.GetFileName(sourcePath)}'.");
            }

            if (!File.Exists(convertedPath) || new FileInfo(convertedPath).Length == 0)
            {
                throw new InvalidOperationException(
                    $"Conversion did not produce a usable PDF for '{Path.GetFileName(sourcePath)}'.");
            }

            return convertedPath;
        }

        private string ConvertZipToPdf(string zipPath, string runFolder)
        {
            string zipName = Path.GetFileName(zipPath);
            string zipWorkFolder = Path.Combine(runFolder, $"zip_{Guid.NewGuid():N}");
            Directory.CreateDirectory(zipWorkFolder);

            Logger.Info($"Extracting ZIP '{zipName}'");

            var extractedFiles = new List<string>();
            string zipRoot = Path.GetFullPath(zipWorkFolder + Path.DirectorySeparatorChar);

            using (var archive = ZipFile.OpenRead(zipPath))
            {
                foreach (var entry in archive.Entries)
                {
                    // Directory entries have no file name component.
                    if (string.IsNullOrEmpty(entry.Name))
                    {
                        continue;
                    }

                    string relativeName = entry.FullName
                        .Replace('/', Path.DirectorySeparatorChar)
                        .Replace('\\', Path.DirectorySeparatorChar);
                    string destinationPath = Path.GetFullPath(Path.Combine(zipWorkFolder, relativeName));

                    // Prevent paths such as ../../somewhere/file.pdf from escaping the
                    // per-ZIP temp folder.
                    if (!destinationPath.StartsWith(zipRoot, StringComparison.OrdinalIgnoreCase))
                    {
                        throw new InvalidDataException(
                            $"ZIP '{zipName}' contains an unsafe entry path: '{entry.FullName}'.");
                    }

                    string destinationDirectory = Path.GetDirectoryName(destinationPath);
                    if (!string.IsNullOrEmpty(destinationDirectory))
                    {
                        Directory.CreateDirectory(destinationDirectory);
                    }

                    entry.ExtractToFile(destinationPath, overwrite: false);
                    extractedFiles.Add(destinationPath);
                    Logger.Debug($"ZIP '{zipName}' extracted entry: {entry.FullName}");
                }
            }

            if (extractedFiles.Count == 0)
            {
                throw new InvalidDataException($"ZIP '{zipName}' did not contain any files.");
            }

            // Keep ordering deterministic. Folder/path + file name sorting is preferable
            // to relying on archive implementation details or filesystem enumeration order.
            extractedFiles = extractedFiles
                .OrderBy(p => GetRelativePathSafe(zipWorkFolder, p), StringComparer.OrdinalIgnoreCase)
                .ToList();

            Logger.Info($"ZIP '{zipName}' contains {extractedFiles.Count} file(s) to convert/merge.");

            var zipPdfParts = new List<string>();
            foreach (string extractedFile in extractedFiles)
            {
                string ext = Path.GetExtension(extractedFile);
                if (!_settings.AllowedExtensions.Contains(ext) || ext.Equals(".zip", StringComparison.OrdinalIgnoreCase))
                {
                    throw new NotSupportedException(
                        $"ZIP '{zipName}' contains unsupported file '{GetRelativePathSafe(zipWorkFolder, extractedFile)}' " +
                        $"(extension '{ext}').");
                }

                zipPdfParts.Add(ResolveFileToPdf(extractedFile, runFolder));
            }

            string zipPdfPath = Path.Combine(
                runFolder,
                $"{Path.GetFileNameWithoutExtension(zipPath)}_zip_{Guid.NewGuid():N}.pdf");

            Logger.Info($"Merging {zipPdfParts.Count} converted file(s) from ZIP '{zipName}' into one PDF.");
            PdfMergerService.Merge(zipPdfParts, zipPdfPath);

            if (!File.Exists(zipPdfPath) || new FileInfo(zipPdfPath).Length == 0)
            {
                throw new InvalidOperationException($"ZIP conversion did not produce a usable PDF for '{zipName}'.");
            }

            return zipPdfPath;
        }

        private static string GetRelativePathSafe(string baseFolder, string fullPath)
        {
            string baseFull = Path.GetFullPath(baseFolder).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
            string targetFull = Path.GetFullPath(fullPath);

            if (targetFull.StartsWith(baseFull, StringComparison.OrdinalIgnoreCase))
            {
                return targetFull.Substring(baseFull.Length);
            }

            return Path.GetFileName(fullPath);
        }

        private void ExcludeGroup(SubmissionGroup group)
        {
            MoveFiles(group.AllFilePaths, _settings.ExcludeDirectory);
        }

        private void TryDeletePartialOutput(SubmissionGroup group)
        {
            string mergedFileName = $"{_settings.Prefix}{group.GroupKey}.pdf";
            string mergedOutputPath = Path.Combine(_settings.OutputDirectory, mergedFileName);
            try
            {
                if (File.Exists(mergedOutputPath))
                {
                    File.Delete(mergedOutputPath);
                    Logger.Warn($"Deleted partially-written merged output: {mergedOutputPath}");
                }
            }
            catch (Exception ex)
            {
                Logger.Warn($"Could not delete partial merged output '{mergedOutputPath}': {ex.Message}");
            }
        }

        private void MoveFiles(IEnumerable<string> sourcePaths, string destinationDirectory)
        {
            Directory.CreateDirectory(destinationDirectory);

            foreach (var sourcePath in sourcePaths)
            {
                if (!File.Exists(sourcePath))
                {
                    Logger.Warn($"Expected to move '{sourcePath}' but it no longer exists - skipping.");
                    continue;
                }

                string destinationPath = Path.Combine(destinationDirectory, Path.GetFileName(sourcePath));
                destinationPath = MakeUniqueIfExists(destinationPath);

                MoveWithRetry(sourcePath, destinationPath);
                Logger.Info($"Moved '{sourcePath}' -> '{destinationPath}'");
            }
        }

        private static string MakeUniqueIfExists(string destinationPath)
        {
            if (!File.Exists(destinationPath)) return destinationPath;

            string dir = Path.GetDirectoryName(destinationPath);
            string name = Path.GetFileNameWithoutExtension(destinationPath);
            string ext = Path.GetExtension(destinationPath);

            for (int i = 1; i < 1000; i++)
            {
                string candidate = Path.Combine(dir, $"{name}_dup{i}{ext}");
                if (!File.Exists(candidate)) return candidate;
            }

            return Path.Combine(dir, $"{name}_{Guid.NewGuid():N}{ext}");
        }

        private static void MoveWithRetry(string sourcePath, string destinationPath, int maxAttempts = 3)
        {
            for (int attempt = 1; attempt <= maxAttempts; attempt++)
            {
                try
                {
                    File.Move(sourcePath, destinationPath);
                    return;
                }
                catch (IOException) when (attempt < maxAttempts)
                {
                    Logger.Warn($"Move attempt {attempt} of {maxAttempts} failed for '{sourcePath}' (file may be locked) - retrying.");
                    Thread.Sleep(500 * attempt);
                }
            }
        }

        private static void CleanupTempFolder(string runFolder)
        {
            try
            {
                if (Directory.Exists(runFolder))
                {
                    Directory.Delete(runFolder, recursive: true);
                }
            }
            catch (Exception ex)
            {
                Logger.Warn($"Could not clean up temp folder '{runFolder}': {ex.Message}");
            }
        }
    }
}
