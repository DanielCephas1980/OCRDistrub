using System;
using System.Collections.Generic;
using System.Linq;

namespace CFAMatch.PdfMerger
{
    /// <summary>
    /// Groups files by the "everything before the last underscore" convention and
    /// validates each group before any conversion work starts. A group fails
    /// validation (and therefore the whole set goes to Exclude) if:
    ///   - any file's extension isn't in AllowedExtensions, or
    ///   - any file doesn't follow the "&lt;submission&gt;_&lt;number&gt;" naming
    ///     convention, or
    ///   - two files in the group claim the same document number.
    /// </summary>
    public static class FileGrouper
    {
        public static List<SubmissionGroup> BuildGroups(IEnumerable<string> filePaths, HashSet<string> allowedExtensions)
        {
            var submissionFiles = filePaths.Select(p => new SubmissionFile(p)).ToList();

            var groups = submissionFiles
                .GroupBy(f => f.GroupKey, StringComparer.OrdinalIgnoreCase)
                .Select(g => new SubmissionGroup(g.Key, g))
                .ToList();

            foreach (var group in groups)
            {
                ValidateGroup(group, allowedExtensions);

                // Only sort when every file in the group has a usable document number -
                // sorting with nulls present would produce a meaningless order and we're
                // excluding the group anyway.
                if (group.IsValid)
                {
                    group.Files.Sort((a, b) => a.DocumentNumber.Value.CompareTo(b.DocumentNumber.Value));
                }
            }

            return groups;
        }

        private static void ValidateGroup(SubmissionGroup group, HashSet<string> allowedExtensions)
        {
            var filesWithoutDocNumber = group.Files.Where(f => !f.HasValidDocumentNumber).ToList();
            if (filesWithoutDocNumber.Any())
            {
                group.MarkInvalid(
                    "File name(s) do not follow the '<submission>_<number>' convention: " +
                    string.Join(", ", filesWithoutDocNumber.Select(f => f.FileName)));
            }

            var disallowed = group.Files.Where(f => !allowedExtensions.Contains(f.Extension)).ToList();
            if (disallowed.Any())
            {
                group.MarkInvalid(
                    "Unsupported/unexpected file extension(s): " +
                    string.Join(", ", disallowed.Select(f => f.FileName)));
            }

            var duplicateDocNumbers = group.Files
                .Where(f => f.HasValidDocumentNumber)
                .GroupBy(f => f.DocumentNumber.Value)
                .Where(g => g.Count() > 1)
                .ToList();
            if (duplicateDocNumbers.Any())
            {
                foreach (var dup in duplicateDocNumbers)
                {
                    group.MarkInvalid(
                        $"Duplicate document number {dup.Key}: " +
                        string.Join(", ", dup.Select(f => f.FileName)));
                }
            }
        }
    }
}
