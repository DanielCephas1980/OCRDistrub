using System;
using System.IO;
using System.Xml.Linq;
using DocumentFormat.OpenXml.Packaging;
using OpenXmlPowerTools;
using PdfSharp.Pdf;
using TheArtOfDev.HtmlRenderer.PdfSharp;
using CFAMatch.PdfMerger;

namespace CFAMatch.PdfMerger.Converters
{
    /// <summary>
    /// Converts a .docx file to a PDF via an HTML intermediate step. This is the same
    /// two-stage approach v1 used (OpenXmlPowerTools for docx -> HTML), but the second
    /// stage (HTML -> PDF) now uses HtmlRenderer.PdfSharp instead of DinkToPdf, so there
    /// is no native wkhtmltopdf DLL to install or LoadLibrary a path to.
    ///
    /// Only .docx (OOXML) is supported. Legacy binary .doc is not - there is no free,
    /// managed-code library that reads the old binary Word format without going through
    /// Office COM automation, which is exactly the kind of fragile install-time
    /// dependency we're trying to avoid. A .doc file in a submission group should be
    /// treated as an unsupported extension upstream (see AppSettings.AllowedExtensions)
    /// so the whole group is routed to Exclude with a clear reason rather than failing
    /// deep inside a conversion call.
    /// </summary>
    public static class WordToPdfConverter
    {
        public static void ConvertDocxToPdf(string docxPath, string pdfPath)
        {
            Logger.Debug($"Converting Word document to HTML: {docxPath}");
            string html = ConvertDocxToHtml(docxPath);

            Logger.Debug($"Rendering HTML to PDF: {pdfPath}");
            using (PdfDocument pdfDocument = PdfGenerator.GeneratePdf(html, PdfSharp.PageSize.A4))
            {
                pdfDocument.Save(pdfPath);
            }
        }

        private static string ConvertDocxToHtml(string docxPath)
        {
            using (var memoryStream = new MemoryStream(File.ReadAllBytes(docxPath)))
            using (WordprocessingDocument wordDoc = WordprocessingDocument.Open(memoryStream, false))
            {
                var settings = new HtmlConverterSettings
                {
                    PageTitle = Path.GetFileNameWithoutExtension(docxPath)
                };

                XElement htmlElement = HtmlConverter.ConvertToHtml(wordDoc, settings);
                return htmlElement.ToStringNewLineOnAttributes();
            }
        }
    }
}
