using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using PdfSharp.Drawing;
using PdfSharp.Pdf;
using CFAMatch.PdfMerger;

namespace CFAMatch.PdfMerger.Converters
{
    /// <summary>
    /// Converts an image file (jpg/jpeg/png/bmp/gif/tif/tiff) to a PDF using only
    /// System.Drawing (built into .NET Framework, no extra package) and PdfSharp - no
    /// ImageMagick/Ghostscript needed since we're not producing a TIFF anymore.
    ///
    /// Multi-frame TIFFs are expanded into one PDF page per frame, which v1 did not
    /// handle (its ImageMagick/Ghostscript path was only reachable for the final
    /// merged-PDF-to-TIFF step, not for multi-page TIFF *inputs*).
    ///
    /// Each frame is re-saved as a temporary PNG on disk and loaded through
    /// XImage.FromFile, mirroring the exact API v1 already used successfully
    /// (XImage.FromFile + XGraphics.DrawImage) rather than relying on a stream-based
    /// overload that may not exist in every PdfSharp 1.50.x build. Temp PNGs are
    /// cleaned up before returning, success or failure.
    /// </summary>
    public static class ImageToPdfConverter
    {
        public static void ConvertImageToPdf(string imagePath, string pdfPath, string tempDirectory)
        {
            Directory.CreateDirectory(tempDirectory);
            var tempFrameFiles = new System.Collections.Generic.List<string>();

            try
            {
                using (var document = new PdfDocument())
                {
                    using (var image = Image.FromFile(imagePath))
                    {
                        FrameDimension frameDimension = GetFrameDimension(image);
                        int frameCount = frameDimension == null ? 1 : image.GetFrameCount(frameDimension);
                        if (frameCount < 1) frameCount = 1;

                        Logger.Debug($"{Path.GetFileName(imagePath)}: {frameCount} frame(s) to place on PDF pages");

                        for (int frameIndex = 0; frameIndex < frameCount; frameIndex++)
                        {
                            if (frameDimension != null && frameCount > 1)
                            {
                                image.SelectActiveFrame(frameDimension, frameIndex);
                            }

                            string tempPngPath = Path.Combine(tempDirectory, $"{Guid.NewGuid():N}_frame{frameIndex}.png");
                            image.Save(tempPngPath, ImageFormat.Png);
                            tempFrameFiles.Add(tempPngPath);

                            AddPageFromImageFile(document, tempPngPath);
                        }
                    }

                    document.Save(pdfPath);
                }
            }
            finally
            {
                foreach (var tempFile in tempFrameFiles)
                {
                    TryDeleteFile(tempFile);
                }
            }
        }

        private static FrameDimension GetFrameDimension(Image image)
        {
            if (image.FrameDimensionsList == null || image.FrameDimensionsList.Length == 0)
            {
                return null;
            }
            return new FrameDimension(image.FrameDimensionsList[0]);
        }

        private static void AddPageFromImageFile(PdfDocument document, string imageFilePath)
        {
            using (XImage xImage = XImage.FromFile(imageFilePath))
            {
                PdfPage page = document.AddPage();
                page.Width = XUnit.FromPoint(xImage.PointWidth);
                page.Height = XUnit.FromPoint(xImage.PointHeight);

                using (XGraphics gfx = XGraphics.FromPdfPage(page))
                {
                    gfx.DrawImage(xImage, 0, 0, page.Width, page.Height);
                }
            }
        }

        private static void TryDeleteFile(string path)
        {
            try
            {
                if (File.Exists(path)) File.Delete(path);
            }
            catch (Exception ex)
            {
                Logger.Warn($"Could not delete temp image frame '{path}': {ex.Message}");
            }
        }
    }
}
