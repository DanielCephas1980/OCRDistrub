using System;
using System.IO;
using System.Text;

namespace CFAMatch.PdfMerger
{
    /// <summary>
    /// Simple, dependency-free logger. Writes every message to the console and to a
    /// per-run log file simultaneously, flushing after every line so the log file is
    /// always current on a network share even if the process is killed mid-run.
    /// Thread safety is provided via a lock since nothing here is meant to be a
    /// bottleneck at the volume this app produces.
    /// </summary>
    public static class Logger
    {
        private static readonly object SyncRoot = new object();
        private static StreamWriter _writer;
        private static bool _verbose;
        public static string LogFilePath { get; private set; }

        public static void Initialize(string logDirectory, string runId, bool verbose)
        {
            lock (SyncRoot)
            {
                _verbose = verbose;
                Directory.CreateDirectory(logDirectory);
                LogFilePath = Path.Combine(logDirectory, $"CFAMatch_PdfMerger_{runId}.log");
                _writer = new StreamWriter(new FileStream(LogFilePath, FileMode.Create, FileAccess.Write, FileShare.Read), Encoding.UTF8)
                {
                    AutoFlush = true
                };
            }
        }

        public static void Debug(string message)
        {
            if (_verbose)
            {
                Write("DEBUG", message);
            }
        }

        public static void Info(string message) => Write("INFO", message);

        public static void Warn(string message) => Write("WARN", message);

        public static void Error(string message) => Write("ERROR", message);

        public static void Error(string message, Exception ex)
        {
            Write("ERROR", $"{message} :: {ex.GetType().Name}: {ex.Message}");
            Write("ERROR", ex.StackTrace ?? "(no stack trace)");
            if (ex.InnerException != null)
            {
                Write("ERROR", $"  Inner: {ex.InnerException.GetType().Name}: {ex.InnerException.Message}");
            }
        }

        private static void Write(string level, string message)
        {
            var line = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff} [{level,-5}] {message}";
            lock (SyncRoot)
            {
                Console.WriteLine(line);
                _writer?.WriteLine(line);
            }
        }

        public static void Shutdown()
        {
            lock (SyncRoot)
            {
                _writer?.Flush();
                _writer?.Dispose();
                _writer = null;
            }
        }
    }
}
