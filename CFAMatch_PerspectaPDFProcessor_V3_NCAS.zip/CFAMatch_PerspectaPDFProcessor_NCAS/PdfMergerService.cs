using System;
using System.Collections.Generic;
using PdfSharp.Pdf;
using PdfSharp.Pdf.IO;

namespace CFAMatch.PdfMerger
{
    /// <summary>
    /// Merges an ordered list of single-source PDFs into one output PDF, page by page,
    /// using PdfSharp import mode - same technique v1 used for the merge step (that
    /// part of v1 wasn't broken, so it isn't being replaced).
    /// </summary>
    public static class PdfMergerService
    {
        public static void Merge(IReadOnlyList<string> orderedPdfPaths, string outputPdfPath)
        {
            if (orderedPdfPaths.Count == 0)
            {
                throw new InvalidOperationException("Cannot merge an empty list of PDF files.");
            }

            using (var outputDocument = new PdfDocument())
            {
                foreach (var pdfFile in orderedPdfPaths)
                {
                    Logger.Debug($"Merging pages from: {pdfFile}");
                    try
                    {
                        using (PdfDocument inputDocument = PdfReader.Open(pdfFile, PdfDocumentOpenMode.Import))
                        {
                            foreach (PdfPage page in inputDocument.Pages)
                            {
                                outputDocument.AddPage(page);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        throw new InvalidOperationException($"Failed to read/merge PDF '{pdfFile}': {ex.Message}", ex);
                    }
                }

                if (outputDocument.PageCount == 0)
                {
                    throw new InvalidOperationException("Merged document ended up with zero pages.");
                }

                outputDocument.Save(outputPdfPath);
            }
        }
    }
}
