using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;

namespace CFAMatch.PdfMerger
{
    /// <summary>
    /// v2 entry point.
    ///
    /// What changed from v1, and why:
    ///   - No more TIFF output. The pipeline stops at the merged PDF. Ghostscript.NET
    ///     and ImageMagick are gone entirely because they existed only for the
    ///     PDF -> TIFF step.
    ///   - Word (.docx) and Excel (.xls/.xlsx) conversion now goes through a
    ///     pure-managed HTML -> PDF path (HtmlRenderer.PdfSharp) instead of
    ///     DinkToPdf + a hardcoded LoadLibrary() call to a wkhtmltopdf DLL on a
    ///     network share. Nothing here needs a native binary installed or registered.
    ///   - CFA vs. NCAS is a single App.config setting (Mode). It controls both the
    ///     "CFA_"/"NCAS_" filename prefix and the folder path (NCAS is derived by
    ///     substituting "NCAS" for the literal "CFA" in BasePath). See AppSettings.cs.
    ///   - A group only merges if EVERY file in it is a supported type and converts
    ///     cleanly. If anything fails, the ENTIRE group - not just the bad file - is
    ///     moved to Exclude. See GroupProcessor.cs.
    ///   - Logging is extensive and goes to both the console and a per-run log file
    ///     under BasePath\Logs, so a scheduled/unattended run always leaves a trail.
    /// </summary>
    internal static class Program
    {
        private static int Main(string[] args)
        {
            var runId = DateTime.Now.ToString("yyyyMMdd_HHmmss");
            AppSettings settings;

            try
            {
                settings = AppSettings.Load();
            }
            catch (Exception ex)
            {
                // Logger isn't initialized yet (it needs settings.LogDirectory), so this
                // one failure mode is console-only.
                Console.WriteLine($"FATAL: Could not load configuration from App.config: {ex.Message}");
                return 2;
            }

            Logger.Initialize(settings.LogDirectory, $"{settings.Mode}_{runId}", settings.VerboseLogging);
            AppDomain.CurrentDomain.UnhandledException += (sender, eventArgs) =>
            {
                Logger.Error("Unhandled exception - process is terminating", eventArgs.ExceptionObject as Exception
                    ?? new Exception(eventArgs.ExceptionObject?.ToString() ?? "unknown error"));
                Logger.Shutdown();
            };

            int exitCode;
            string mutexName = $"Global\\CFAMatch_PdfMerger_{settings.Mode}";
            using (var runLock = new Mutex(initiallyOwned: true, name: mutexName, createdNew: out bool acquiredLock))
            {
                if (!acquiredLock)
                {
                    Logger.Warn($"Another instance is already processing Mode={settings.Mode}. Exiting without doing any work.");
                    Logger.Shutdown();
                    return 1;
                }

                try
                {
                    exitCode = Run(settings);
                }
                catch (Exception ex)
                {
                    Logger.Error("Unhandled exception in Run() - aborting", ex);
                    exitCode = 3;
                }
                finally
                {
                    runLock.ReleaseMutex();
                }
            }

            Logger.Shutdown();
            return exitCode;
        }

        private static int Run(AppSettings settings)
        {
            Logger.Info("=======================================================");
            Logger.Info($"CFAMatch PDF Merger v3 starting - Mode={settings.Mode}");
            Logger.Info($"Source directory:    {settings.SourceDirectory}");
            Logger.Info($"Output directory:    {settings.OutputDirectory}");
            Logger.Info($"Processed directory: {settings.ProcessedDirectory}");
            Logger.Info($"Exclude directory:   {settings.ExcludeDirectory}");
            Logger.Info($"Temp directory:      {settings.TempDirectory}");
            Logger.Info($"Allowed extensions:  {string.Join(", ", settings.AllowedExtensions.OrderBy(e => e))}");
            Logger.Info("=======================================================");

            if (!Directory.Exists(settings.SourceDirectory))
            {
                Logger.Error($"Source directory does not exist or is not reachable: {settings.SourceDirectory}");
                return 4;
            }

            Directory.CreateDirectory(settings.OutputDirectory);
            Directory.CreateDirectory(settings.ProcessedDirectory);
            Directory.CreateDirectory(settings.ExcludeDirectory);
            Directory.CreateDirectory(settings.TempDirectory);

            // Top-directory only - deliberately does NOT recurse into Output/Processed/
            // Exclude/Temp/Logs, which all live under SourceDirectory.
            string[] allFiles = Directory.GetFiles(settings.SourceDirectory, "*.*", SearchOption.TopDirectoryOnly);
            Logger.Info($"Found {allFiles.Length} file(s) in source directory.");

            if (allFiles.Length == 0)
            {
                Logger.Info("Nothing to process. Exiting.");
                return 0;
            }

            List<SubmissionGroup> groups = FileGrouper.BuildGroups(allFiles, settings.AllowedExtensions);
            Logger.Info($"Grouped into {groups.Count} submission(s).");

            var processor = new GroupProcessor(settings);
            int succeeded = 0;
            int excluded = 0;

            foreach (var group in groups)
            {
                try
                {
                    var result = processor.Process(group);
                    if (result == ProcessResult.Success) succeeded++;
                    else excluded++;
                }
                catch (Exception ex)
                {
                    // GroupProcessor already catches and routes its own failures to
                    // Exclude - this is a last-resort safety net so one bad group can
                    // never take down the whole batch.
                    Logger.Error($"Unexpected error processing group '{group.GroupKey}' - continuing with next group", ex);
                    excluded++;
                }
            }

            Logger.Info("=======================================================");
            Logger.Info($"Run complete. Groups processed: {groups.Count} | Merged: {succeeded} | Excluded: {excluded}");
            Logger.Info($"Log file: {Logger.LogFilePath}");
            Logger.Info("=======================================================");

            return 0;
        }
    }
}
