using System.IO;

namespace CFAMatch.PdfMerger
{
    /// <summary>
    /// One file on disk that belongs to a submission, e.g. 2026-7-9_15-20-44_3.docx.
    /// GroupKey is everything before the last underscore ("2026-7-9_15-20-44") and
    /// DocumentNumber is the numeric piece after it (3), used to order the merge.
    /// </summary>
    public sealed class SubmissionFile
    {
        public string FullPath { get; }
        public string FileName { get; }
        public string Extension { get; }
        public string GroupKey { get; }
        public int? DocumentNumber { get; }

        public bool HasValidDocumentNumber => DocumentNumber.HasValue;

        public SubmissionFile(string fullPath)
        {
            FullPath = fullPath;
            FileName = Path.GetFileName(fullPath);
            Extension = Path.GetExtension(fullPath);

            var nameWithoutExtension = Path.GetFileNameWithoutExtension(fullPath);
            var lastUnderscore = nameWithoutExtension.LastIndexOf('_');

            if (lastUnderscore <= 0 || lastUnderscore == nameWithoutExtension.Length - 1)
            {
                // No underscore, underscore is the first character, or underscore is the
                // last character - none of these match the expected
                // "<submission>_<docnumber>" naming convention.
                GroupKey = nameWithoutExtension;
                DocumentNumber = null;
                return;
            }

            GroupKey = nameWithoutExtension.Substring(0, lastUnderscore);
            var suffix = nameWithoutExtension.Substring(lastUnderscore + 1);

            if (int.TryParse(suffix, out var docNumber))
            {
                DocumentNumber = docNumber;
            }
            else
            {
                DocumentNumber = null;
            }
        }
    }
}
